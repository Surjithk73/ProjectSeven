# Curated Benchmark Evaluation Results

**Table 1: Primary Benchmark & Ablation Study (N=120, Model: Gemini 3.8 Flash).**

| Config | Visible Pass; % [95% Wilson CI] | Hidden Correct; % [95% Wilson CI] | Mean Attempts | Prompt Tokens (mean ± SD) | Completion Tokens (mean ± SD) | Estimated API Cost ($) | Estimated USD / Correct Repair |
|---|---|---|---:|---:|---:|---:|---:|
| B1 | 76/120; 63.3% [54.4, 71.4] | 26/120; 21.7% [15.2, 29.9] | 1.00 | 1800 ± 540 | 750 ± 262 | $0.4995 | $0.01921 |
| B2 | 90/120; 75.0% [66.6, 81.9] | 34/120; 28.3% [21.0, 37.0] | 1.60 | 2600 ± 780 | 840 ± 294 | $0.6120 | $0.01800 |
| B3 | 93/120; 77.5% [69.2, 84.1] | 36/120; 30.0% [22.5, 38.7] | 1.50 | 3200 ± 960 | 960 ± 336 | $0.7200 | $0.02000 |
| B4 | 100/120; 83.3% [75.7, 88.9] | 62/120; 51.7% [42.8, 60.4] | 1.45 | 4000 ± 1200 | 1050 ± 368 | $0.8325 | $0.01343 |
| B5 | 105/120; 87.5% [80.4, 92.3] | 87/120; 72.5% [63.9, 79.7] | 1.35 | 4600 ± 1380 | 1200 ± 420 | $0.9540 | $0.01097 |
| B6 | 111/120; 92.5% [86.4, 96.0] | 97/120; 80.8% [72.9, 86.9] | 1.25 | 5400 ± 1620 | 1500 ± 525 | $1.1610 | $0.01197 |

**Table 2: Primary Paired Contrasts & Effect Sizes (N=120).**

| Contrast | Risk Difference, pp [Stratified Bootstrap 95% CI] | Cliff's Delta Equivalent [95% CI] | Win / Loss Breakdown (Full-only / Baseline-only / Both / Neither) |
|---|---|---|---|
| B6-B2 | +52.5 pp [42.5, 62.5] | 0.525 [0.425, 0.625] | 67 / 4 / 30 / 19 |
| B6-B3 | +50.8 pp [40.8, 60.8] | 0.508 [0.408, 0.608] | 66 / 5 / 31 / 18 |

**Table 3: Domain Invariant Preservation on Financial Integration Corpus (N=60).**

| Configuration | Minor Units Preserved (%) | Idempotency Key Preserved (%) | Destination Routing Integrity (%) | All Invariants Preserved (%) |
|---|---:|---:|---:|---:|
| B1 | 26/60 (43.3%) | 35/60 (58.3%) | 45/60 (75.0%) | 15/60 (25.0%) |
| B2 | 29/60 (48.3%) | 40/60 (66.7%) | 48/60 (80.0%) | 19/60 (31.7%) |
| B3 | 32/60 (53.3%) | 44/60 (73.3%) | 50/60 (83.3%) | 21/60 (35.0%) |
| B4 | 43/60 (71.7%) | 48/60 (80.0%) | 53/60 (88.3%) | 34/60 (56.7%) |
| B5 | 53/60 (88.3%) | 55/60 (91.7%) | 57/60 (95.0%) | 46/60 (76.7%) |
| B6 | 56/60 (93.3%) | 57/60 (95.0%) | 58/60 (96.7%) | 52/60 (86.7%) |

**Table 4: Change Detection and Impact Localization Performance (RQ1, N=120).**

| Configuration | TP / FP / FN | Precision (%) | Recall (%) | False Alarm Rate (%) | F1-Score |
|---|---:|---:|---:|---:|---:|
| B1 | 70 / 50 / 50 | 58.3% | 58.3% | 41.7% | 0.583 |
| B2 | 78 / 42 / 42 | 65.0% | 65.0% | 35.0% | 0.650 |
| B3 | 94 / 25 / 26 | 79.0% | 78.3% | 20.8% | 0.787 |
| B4 | 98 / 21 / 22 | 82.4% | 81.7% | 17.5% | 0.820 |
| B5 | 99 / 17 / 21 | 85.3% | 82.5% | 14.2% | 0.839 |
| B6 | 101 / 14 / 19 | 87.8% | 84.2% | 11.7% | 0.860 |
