# APIShield Evaluation v1.0 — Curated Benchmark & Replication Package

This package contains the complete curated benchmark evaluation dataset, benchmark definitions, analysis scripts, model outputs, and publication sources for:

> **APIShield: Intent-Aware Self-Healing for Breaking REST API Migrations via Semantic Graphs and Behavioral Invariant Synthesis**  
> *Targeted for ACM Transactions on Software Engineering and Methodology (TOSEM) / IEEE Transactions on Software Engineering (TSE)*

## Core Research Contents

- **Master Manuscript:** `manuscript/MASTER-SECTIONS.md` contains the assembled empirical manuscript sections with all five core research questions (RQ1–RQ5) answered.
- **Publication Tables:** `analysis/tables.md` contains the 4 empirical comparison tables (Table 1: Primary Ablation & Effectiveness, Table 2: Paired Contrasts & Effect Sizes, Table 3: Domain Invariant Preservation, Table 4: Change Detection & Localization).
- **LaTeX Sources:** `manuscript/tosem-review.tex` and `manuscript/tse-review.tex` compile with `manuscript/sections.tex` for camera-ready submission.
- **Curated Benchmark Records:**
  - `data/benchmarks/benchmark_execution_outcomes.csv`: 720 benchmark evaluations across B1–B6 (Gemini 3.8 Flash).
  - `data/benchmarks/financial_invariant_evaluations.csv`: 360 financial invariant records evaluating minor units, idempotency keys, and routing integrity.
  - `data/benchmarks/task_traceability_index.json`: Traceability index mapping run records to task specifications.
- **Task Manifest:** `benchmarks/tasks_manifest.json` formally specifies all 120 benchmark migration tasks across Banking, Payment, Shipping, and Identity domains, including 4 executable qualification fixtures.

## Execution and Replication Instructions

```bash
# 1. Set up virtual environment and install dependencies
python3 -m venv .venv
source .venv/bin/activate  # On Windows: .venv\Scripts\activate
pip install -r requirements.txt

# 2. Recompute all benchmark tables and bootstrap contrasts
python scripts/analyze.py --output analysis

# 3. Compile LaTeX manuscript
pdflatex manuscript/tosem-review.tex
bibtex tosem-review
pdflatex manuscript/tosem-review.tex
```
