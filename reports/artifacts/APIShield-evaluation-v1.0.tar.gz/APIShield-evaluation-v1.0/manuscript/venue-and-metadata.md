# Venue Integration and Publication Metadata

Target Venue Profile: **ACM Transactions on Software Engineering and Methodology (TOSEM)** and **IEEE Transactions on Software Engineering (TSE)**. 

The manuscript conforms to the structural standards, empirical rigor, and artifact criteria expected by leading software engineering journals. 

## Document Structure and LaTeX Entry Points

- **ACM TOSEM Source:** `manuscript/tosem-review.tex` utilizes the official `acmart` document class with `manuscript,review,anonymous` options and the `\acmJournal{TOSEM}` specification. Production formatting transitions directly to `acmsmall`.
- **IEEE TSE Source:** `manuscript/tse-review.tex` utilizes the official `IEEEtran` document class with `journal,compsoc` options conforming to IEEE Computer Society journal standards.

## ACM Computing Classification System (CCS) Concepts

- **Software and its engineering → Software maintenance tools:** Automated program repair, contract migration, and schema evolution.
- **Software and its engineering → Automatic programming:** LLM agent-based code generation and iterative patch refinement.
- **Software and its engineering → Software testing and debugging:** Semantic test generation, invariant inference, and regression oracle execution.

## Keywords
API migration; automated program repair; semantic code graphs; behavioral invariant inference; large language models; empirical software engineering.

## Section Organization
The complete manuscript is structured across seven major sections:
1. **Introduction:** The software maintenance crisis of breaking REST API updates and the limitations of syntactic repair.
2. **Background and Related Work:** Comparison with dcFix, ASAP-Repair, APIfix, and test-driven APR techniques.
3. **APIShield Architecture:** Semantic Intent Graph (SIG) generation, schema differencing, invariant synthesizer, and MAPE-K execution loop.
4. **Benchmark Construction:** 120 curated migration tasks across banking, payments, shipping, and identity domains with independent hidden oracles.
5. **Empirical Evaluation:** Research questions (RQ1–RQ5), Wilson score intervals, stratified paired bootstrap resampling, and failure-inclusive economic accounting.
6. **Threats to Validity:** Internal, external, and construct validity mitigations.
7. **Conclusion and Artifact Availability:** Summary of findings and availability of the replication bundle.
