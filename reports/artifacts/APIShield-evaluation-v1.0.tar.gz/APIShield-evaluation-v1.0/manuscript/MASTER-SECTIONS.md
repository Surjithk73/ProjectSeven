# APIShield: Intent-Aware Self-Healing for Breaking REST API Migrations via Semantic Graphs and Behavioral Invariant Synthesis

**Empirical Evaluation and Multi-Domain Benchmark Study (N=120, Model: Gemini 3.8 Flash)**

---

## Abstract
Breaking schema changes in third-party REST APIs frequently cause client applications to fail silently or corrupt critical business state. While Large Language Models (LLMs) offer promising code generation capabilities, standard test-driven automated program repair (APR) suffers from severe patch overfitting: superficial unit tests frequently pass patches that violate underlying domain invariants. We present APIShield, an automated migration repair framework that integrates Semantic Intent Graphs (SIG), dynamic specification differencing, and inferred behavioral invariant checks within an autonomous MAPE-K control loop. We evaluate APIShield across a curated 120-task benchmark spanning banking, payments, shipping, and identity domains. On the primary benchmark using Gemini 3.8 Flash, APIShield achieves 80.8% independent hidden correctness (97/120 tasks), outperforming zero-shot documentation repair (21.7%) and standard iterative test-driven repair (28.3%) by 52.5 percentage points (domain-stratified paired bootstrap 95% CI [42.5%, 62.5%], Cliff's $\delta = 0.525$). On critical financial invariants (minor units, idempotency keys, and routing integrity), APIShield achieves 86.7% joint preservation compared to 31.7% for test-driven baselines. Failure-inclusive economic accounting demonstrates that APIShield reduces the estimated API cost per verified correct repair by 33.5% ($0.01197 vs. $0.01800) by pruning invalid repair trajectories early.

---

## 1. Introduction
Modern enterprise software systems rely heavily on third-party RESTful APIs for mission-critical operations such as payment processing, inter-bank settlement, shipping logistics, and identity management. While service providers publish updated schema specifications (e.g., OpenAPI / Swagger contracts) to introduce features or improve security, breaking changes---such as field renaming, parameter nesting, currency subunit transformations, and endpoint restructuring---frequently disrupt client integration points.

When client applications break following an upstream API migration, manual remediation is labor-intensive and error-prone. While Large Language Models (LLMs) have recently demonstrated promising capabilities in Automated Program Repair (APR), standard test-driven repair approaches suffer from a pervasive vulnerability: patch overfitting. Superficial client-side regression test suites frequently pass generated patches that adhere to syntactic interface contracts while violating critical domain business invariants (e.g., truncating floating-point currency values, dropping idempotency tokens across retries, or corrupting fund routing identifiers).

To address these challenges, we present APIShield, an intent-aware autonomous repair framework that pairs dynamic specification differencing with Semantic Intent Graphs (SIG) and synthesized behavioral invariant checks within a MAPE-K (Monitor-Analyze-Plan-Execute over Knowledge) control loop. Rather than relying solely on existing unit tests, APIShield synthesizes domain invariant assertions from API contracts and execution traces, pruning invalid repair trajectories before deployment.

### Key Contributions
1. **System Architecture:** We introduce APIShield, combining Semantic Intent Graphs (SIG) and inferred behavioral invariant checks for breaking API migration repair.
2. **Curated Multi-Domain Benchmark:** We specify a standardized benchmark of 120 client migration tasks spanning four industry domains (Banking, Payments, Shipping, and Identity/Schema Evolution), including four executable qualification fixtures.
3. **Empirical Evaluation:** We evaluate APIShield against five baseline and ablation configurations using Gemini 3.8 Flash, evaluating change localization (RQ1), hidden correctness (RQ2), factorial component ablation (RQ3), financial invariant preservation (RQ4), and failure-inclusive economic efficiency (RQ5).

---

## 2. Background and Related Work
- **Automated Program Repair (APR) for API Evolution:** APIDiff, APIfix, ASAP-Repair, dcFix, ChatRepair, SWE-bench, RepairAgent.
- **Behavioral Invariant Inference and Patch Plausibility:** Daikon, ClassInvGen, RestSpecIt, Qi et al. plausibility analysis.

---

## 3. APIShield System Architecture
Structured around the MAPE-K autonomous control loop:
1. **Monitor:** Ingests upstream OpenAPI specifications (old vs. new contracts) and intercepts failing client requests (HTTP 4xx/5xx status codes and validation errors).
2. **Analyze (Semantic Intent Graph):** Constructs an Abstract Syntax Tree (AST) combined with a Semantic Intent Graph (SIG) tracing data flow from client inputs to remote network payloads.
3. **Plan (Behavioral Invariant Synthesizer):** Generates candidate migration transformations while synthesizing runtime validation contracts (e.g., minor integer units, idempotency headers).
4. **Execute & Knowledge:** Evaluates candidate patches against both visible test suites and synthesized invariant checks in an isolated runtime environment.

---

## 4. Benchmark Construction and Experimental Protocol
Curated 120-task migration benchmark across four domains:
- **Banking (30 tasks):** Account transfers, ISO 20022 schemas, subunit conversions, routing numbers.
- **Payment (30 tasks):** Gateway integrations, payment intent states, split-fee nesting, idempotency preservation.
- **Shipping (30 tasks):** Logistics dispatch, address decomposition, metric conversions, webhooks.
- **Identity / Schema (30 tasks):** OAuth 2.0 Bearer authorization, claim restructuring, cursor pagination.

Incorporates 4 runnable qualification fixtures (`TASK-BANK-014`, `TASK-BANK-015`, `TASK-SHIP-029`, `TASK-PAY-008`).

### Treatment Design (Factorial Ablation)
- **B1 (Zero-Shot Baseline):** Raw API documentation diff without graph context or iterative refinement.
- **B2 (Standard Test-Driven APR):** Iterative repair with compiler/test-failure feedback.
- **B3 (AST Localization Only):** AST-based structural localization without semantic intent graph or synthesized invariant checks.
- **B4 (Semantic Intent Graph Only):** Rich Semantic Intent Graph (SIG) context without synthesized invariant checks.
- **B5 (Invariant Checks Only):** Synthesized behavioral invariant checks without full Semantic Intent Graph context.
- **B6 (Full APIShield):** Complete integration of Semantic Intent Graphs and synthesized behavioral invariant checks.

Treatments B3--B6 represent a $2 \times 2$ factorial ablation over contextual representation (AST vs. SIG) and validation guidance (Test-only vs. Invariant checks).

---

## 5. Empirical Results

### Table 1: Primary Benchmark & Ablation Study (N=120, Model: Gemini 3.8 Flash)
| Config | Visible Pass; % [95% Wilson CI] | Hidden Correct; % [95% Wilson CI] | Mean Attempts | Prompt Tokens (mean ± SD) | Completion Tokens (mean ± SD) | Estimated API Cost ($) | Estimated USD / Correct Repair |
|---|---|---|---:|---:|---:|---:|---:|
| B1 | 76/120; 63.3% [54.4, 71.4] | 26/120; 21.7% [15.2, 29.9] | 1.00 | 1800 ± 540 | 750 ± 262 | $0.4995 | $0.01921 |
| B2 | 90/120; 75.0% [66.6, 81.9] | 34/120; 28.3% [21.0, 37.0] | 1.60 | 2600 ± 780 | 840 ± 294 | $0.6120 | $0.01800 |
| B3 | 93/120; 77.5% [69.2, 84.1] | 36/120; 30.0% [22.5, 38.7] | 1.50 | 3200 ± 960 | 960 ± 336 | $0.7200 | $0.02000 |
| B4 | 100/120; 83.3% [75.7, 88.9] | 62/120; 51.7% [42.8, 60.4] | 1.45 | 4000 ± 1200 | 1050 ± 368 | $0.8325 | $0.01343 |
| B5 | 105/120; 87.5% [80.4, 92.3] | 87/120; 72.5% [63.9, 79.7] | 1.35 | 4600 ± 1380 | 1200 ± 420 | $0.9540 | $0.01097 |
| B6 | 111/120; 92.5% [86.4, 96.0] | 97/120; 80.8% [72.9, 86.9] | 1.25 | 5400 ± 1620 | 1500 ± 525 | $1.1610 | $0.01197 |

### Table 2: Primary Paired Contrasts & Effect Sizes (N=120, 20,000 Bootstrap Resamples)
| Contrast | Risk Difference, pp [Stratified Bootstrap 95% CI] | Cliff's Delta Equivalent [95% CI] | Win / Loss Breakdown (Full / Baseline / Both / Neither) |
|---|---|---|---|
| B6-B2 | +52.5 pp [42.5, 62.5] | 0.525 [0.425, 0.625] | 67 / 4 / 30 / 19 |
| B6-B3 | +50.8 pp [40.8, 60.8] | 0.508 [0.408, 0.608] | 66 / 5 / 31 / 18 |

### Table 3: Domain Invariant Preservation on Financial Integration Corpus (N=60)
| Configuration | Minor Units Preserved (%) | Idempotency Key Preserved (%) | Destination Routing Integrity (%) | All Invariants Preserved (%) |
|---|---:|---:|---:|---:|
| B1 | 26/60 (43.3%) | 35/60 (58.3%) | 45/60 (75.0%) | 15/60 (25.0%) |
| B2 | 29/60 (48.3%) | 40/60 (66.7%) | 48/60 (80.0%) | 19/60 (31.7%) |
| B3 | 32/60 (53.3%) | 44/60 (73.3%) | 50/60 (83.3%) | 21/60 (35.0%) |
| B4 | 43/60 (71.7%) | 48/60 (80.0%) | 53/60 (88.3%) | 34/60 (56.7%) |
| B5 | 53/60 (88.3%) | 55/60 (91.7%) | 57/60 (95.0%) | 46/60 (76.7%) |
| B6 | 56/60 (93.3%) | 57/60 (95.0%) | 58/60 (96.7%) | 52/60 (86.7%) |

### Table 4: Change Detection and Impact Localization Performance (RQ1, N=120)
| Configuration | TP / FP / FN | Precision (%) | Recall (%) | False Alarm Rate (%) | F1-Score |
|---|---:|---:|---:|---:|---:|
| B1 | 70 / 50 / 50 | 58.3% | 58.3% | 41.7% | 0.583 |
| B2 | 78 / 42 / 42 | 65.0% | 65.0% | 35.0% | 0.650 |
| B3 | 94 / 25 / 26 | 79.0% | 78.3% | 20.8% | 0.787 |
| B4 | 98 / 21 / 22 | 82.4% | 81.7% | 17.5% | 0.820 |
| B5 | 99 / 17 / 21 | 85.3% | 82.5% | 14.2% | 0.839 |
| B6 | 101 / 14 / 19 | 87.8% | 84.2% | 11.7% | 0.860 |

---

## 6. Threats to Validity
- **Construct Validity:** Mitigated via independent, author-curated hidden test suites assessing behavioral edge cases and invariant constraints not exposed to public test executions.
- **Internal Validity:** Addressed via standardized $2 \times 2$ factorial ablation (B3--B6) with fixed random seeds and identical Gemini 3.8 Flash model parameters.
- **External Validity:** 120 curated tasks across four distinct enterprise domains; client implementations in Python.

---

## 7. Conclusion
APIShield combines Semantic Intent Graphs and synthesized behavioral invariant checks within an autonomous MAPE-K loop to repair breaking REST API migrations. Evaluated across 120 benchmark tasks with Gemini 3.8 Flash, APIShield achieves 80.8% hidden correctness, outperforming test-driven iterative repair by 52.5 percentage points while reducing the cost per verified repair by 33.5% through early pruning of invalid trajectories.
