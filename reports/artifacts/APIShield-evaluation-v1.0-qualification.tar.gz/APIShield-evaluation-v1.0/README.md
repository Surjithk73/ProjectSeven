# APIShield evaluation v1.0 — local review artifact

This package contains synthetic evaluation tables, actual Gemini inference diagnostics and authored executable qualification fixtures. These three evidence categories are separate. It is not a completed 120-task empirical benchmark, a camera-ready accepted article, or a badged public archive.

Start with `manuscript/MASTER-SECTIONS.md` for the complete inclusion text, `analysis/tables.md` for computed tables, `references/references.bib` for twelve verified representative citations, and `manuscript/reproducibility-appendix.md` for exact reproduction commands and record semantics. `DIRECTORY_MANIFEST.txt` enumerates every archive path; `MANIFEST.json` records SHA-256, MD5 and bytes for the payload.

## Tested local dependencies

The analysis was run with Python 3.13.3, NumPy 2.5.4, pandas 2.3.3 and SciPy 1.16.3. Full analysis pins are in `benchmarks/requirements-analysis.txt`. Google SDK dependencies for optional live requests are in `benchmarks/requirements-live.txt`. Cloud requests use a private service-account JSON outside the package. There is no API key or service-account private key in the archive.

## Three reproduction operations

After extracting the tarball, use a POSIX shell:

```bash
cd APIShield-evaluation-v1.0
python3 -c 'import sys; assert sys.version_info[:2] == (3, 13), sys.version'
python3 -m venv .venv
.venv/bin/python -m pip install -r benchmarks/requirements-analysis.txt

# 1. Verify environment and payload
.venv/bin/python scripts/verify_environment.py

# 2. Recompute analysis from the explicitly synthetic raw records
.venv/bin/python scripts/analyze.py --output analysis-reproduced
diff -u analysis/comparison.csv analysis-reproduced/comparison.csv
diff -u analysis/metrics.json analysis-reproduced/metrics.json

# 3. Run one authored fixture headlessly without cloud access
CASE_OUTPUT="$(mktemp -d)/case"
.venv/bin/python scripts/headless.py --mode fixture --task TASK-BANK-014 --config B6 --output "$CASE_OUTPUT"
```

The Windows preparation host ran these Python entry points with its existing environments. The extracted single-case command is also checked from a directory outside Git. POSIX shell commands are supplied for the migration host; no Linux container execution is claimed on the preparation host.

The default headless case is an authored qualification repair. It does not invoke Gemini. Live mode is explicit, requires a content-addressed Docker image, and refuses host execution of generated code. The current machine lacks a working Docker engine and a capable installed open-weight runtime. The archive contains the configuration and OS probes without claiming they have executed successfully.

The top-level statistical script accepts only `SYNTHETIC_PROJECTION` rows and does not pool observed responses with projected outcomes. Its retry counts are explicit synthetic budgeting assumptions; aggregate tokens already include all modeled attempts and stages. Unexecuted observed hidden checks remain NOT_EVALUATED.

## Venue and rights status

The TOSEM and TSE files are separate review-layout profiles with a shared anonymous author block. No author identity, affiliation, DOI, publisher rights block, archive license or journal acceptance is invented. The full venue-specific author kit, real author metadata, rights and redistribution license require confirmation before public submission. TeX compilation was unavailable locally; no rendered-PDF verification is claimed.

The existing Git HEAD recorded by the original runs is not a clean artifact revision. Content hashes identify this package. No new Git commit, public deposit, DOI or badge was created during packaging.
