"""Verify archive bytes and report local capabilities without requiring a GPU."""
import argparse
import hashlib
import importlib.metadata
import json
import platform
import shutil
import subprocess
import sys
from pathlib import Path

ROOT=Path(__file__).resolve().parents[1]

def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--require-docker',action='store_true')
    args=p.parse_args()
    manifest=json.loads((ROOT/'MANIFEST.json').read_text())
    for rel,expected in manifest['files'].items():
        path=ROOT/rel
        if hashlib.sha256(path.read_bytes()).hexdigest()!=expected['sha256']:raise ValueError('Payload mismatch: '+rel)
    deps={name:importlib.metadata.version(name) for name in ['numpy','pandas','scipy']}
    docker=False
    if shutil.which('docker'):
        try:docker=subprocess.run(['docker','info'],capture_output=True,timeout=15).returncode==0
        except (OSError,subprocess.TimeoutExpired):pass
    report={'python':sys.version,'platform':platform.platform(),'dependencies':deps,
        'payload_files_verified':len(manifest['files']),'docker_engine_available':docker,
        'llama_server_available':bool(shutil.which('llama-server')),'nvidia_smi_available':bool(shutil.which('nvidia-smi')),
        'empirical_120_task_evaluation_present':False,'evidence_status':'synthetic manuscript layout plus observed diagnostics and authored fixtures'}
    print(json.dumps(report,indent=2))
    if args.require_docker and not docker:raise SystemExit(2)

if __name__=='__main__':main()
