"""Recompute labelled synthetic tables; never pool them with observed execution logs."""
import argparse
import json
from pathlib import Path

import numpy as np
import pandas as pd
from scipy.stats import norm

ROOT=Path(__file__).resolve().parents[1]

def wilson(successes,total):
    if total<=0:return None,None
    z=norm.ppf(.975);p=successes/total;den=1+z*z/total
    mid=(p+z*z/(2*total))/den
    half=z*np.sqrt(p*(1-p)/total+z*z/(4*total*total))/den
    return float(mid-half),float(mid+half)

def cliffs_delta(x,y):
    difference=np.asarray(x)[:,None]-np.asarray(y)[None,:]
    return float(((difference>0).sum()-(difference<0).sum())/difference.size)

def paired_bootstrap(left,right,families,draws=20000):
    rng=np.random.default_rng(42)
    groups=[np.flatnonzero(families==family) for family in sorted(set(families))]
    deltas=[];ratios=[]
    for _ in range(draws):
        index=np.concatenate([rng.choice(group,len(group),replace=True) for group in groups])
        # For binary outcomes, marginal Cliff's delta equals the difference in means.
        deltas.append(float((left[index]-right[index]).mean()))
        ratios.append(float(left[index].mean()-right[index].mean()))
    return np.quantile(deltas,[.025,.975]).tolist(),np.quantile(ratios,[.025,.975]).tolist()

def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--data',type=Path,default=ROOT/'data/synthetic/synthetic_outcomes.csv')
    p.add_argument('--output',type=Path,default=ROOT/'analysis')
    args=p.parse_args()
    frame=pd.read_csv(args.data)
    if set(frame.record_kind)!={'SYNTHETIC_PROJECTION'}:
        raise ValueError('This analysis accepts only explicitly synthetic records')
    if frame.duplicated(['task_id','configuration']).any():raise ValueError('Duplicate task/configuration')
    if set(frame.configuration)!={f'B{i}' for i in range(1,7)}:raise ValueError('Expected B1-B6')
    frame['domain']=frame.task_id.str.split('-').str[1]
    for column in ['hidden_pass','visible_pass']:
        if not pd.api.types.is_bool_dtype(frame[column]):raise ValueError('Expected boolean outcomes')
    if (frame.hidden_pass & ~frame.visible_pass).any():raise ValueError('Hidden correctness requires visible success')
    # Retry allocations are explicit synthetic budgeting assumptions, not recovered measurements.
    extras={'B1':0,'B2':72,'B3':60,'B4':54,'B5':42,'B6':30}
    enriched=[];summaries=[]
    for config,original in frame.groupby('configuration',sort=True):
        group=original.sort_values('task_id').copy()
        if len(group)!=120:raise ValueError('Expected 120 tasks per configuration')
        attempts=np.ones(120,dtype=int)
        ranking=np.argsort(-group.wall_seconds.to_numpy())
        for index in range(extras[config]):attempts[ranking[index%120]]+=1
        group['synthetic_repair_attempts']=attempts
        group['token_accounting']='aggregate_including_all_attempts_and_model_stages'
        api=(.75*group.prompt_tokens+3.75*group.completion_including_reasoning_tokens)/1e6
        cost=api+group.wall_seconds*(.08+.065*.20)/3600
        if not np.allclose(api,group.estimated_api_usd):raise ValueError('API cost identity failed')
        if not np.allclose(cost,group.modeled_total_usd):raise ValueError('Total cost identity failed')
        v=int(group.visible_pass.sum());h=int(group.hidden_pass.sum());n=len(group)
        vlo,vhi=wilson(v,n);hlo,hhi=wilson(h,n)
        summaries.append(dict(config_id=config,tasks=n,visible_successes=v,visible_rate=v/n,
            visible_ci_low=vlo,visible_ci_high=vhi,hidden_successes=h,hidden_rate=h/n,
            hidden_ci_low=hlo,hidden_ci_high=hhi,
            detection_precision=float(group.true_affected_localized.sum()/(group.true_affected_localized.sum()+group.unaffected_false_alarm.sum())),
            detection_recall=float(group.true_affected_localized.mean()),
            prompt_tokens_total=int(group.prompt_tokens.sum()),completion_tokens_total=int(group.completion_including_reasoning_tokens.sum()),
            mean_repair_attempts=float(attempts.mean()),runtime_mean=float(group.wall_seconds.mean()),
            runtime_sd=float(group.wall_seconds.std(ddof=1)),api_cost_total=float(api.sum()),
            host_cost_total=float((cost-api).sum()),failure_inclusive_cost_total=float(cost.sum()),
            failure_inclusive_cost_per_hidden_correct=float(cost.sum()/h)))
        enriched.append(group)
    frame=pd.concat(enriched,ignore_index=True)
    effects=[]
    for baseline in ['B2','B3']:
        paired=frame[frame.configuration.isin(['B6',baseline])].pivot(index='task_id',columns='configuration',values='hidden_pass').sort_index()
        left=paired['B6'].astype(int).to_numpy();right=paired[baseline].astype(int).to_numpy()
        families=paired.index.to_series().str.split('-').str[1].to_numpy()
        rd_ci,delta_ci=paired_bootstrap(left,right,families)
        effects.append(dict(contrast='B6-'+baseline,paired_tasks=len(paired),risk_difference=float((left-right).mean()),
            paired_stratified_bootstrap_95=rd_ci,cliffs_delta=cliffs_delta(left,right),
            cliffs_delta_paired_stratified_bootstrap_95=delta_ci,
            baseline_only=int(((left==0)&(right==1)).sum()),full_only=int(((left==1)&(right==0)).sum()),
            both_correct=int(((left==1)&(right==1)).sum()),neither_correct=int(((left==0)&(right==0)).sum())))
    args.output.mkdir(parents=True,exist_ok=True)
    pd.DataFrame(summaries).to_csv(args.output/'comparison.csv',index=False)
    frame.to_csv(args.output/'synthetic_accounting.csv',index=False)
    report={'evidence_kind':'synthetic_projection','empirical_claims_supported':False,'schema_version':'1.0',
        'bootstrap_seed':42,'bootstrap_draws':20000,'bootstrap_unit':'paired task, stratified by four domains',
        'ci_scope':'Conditional on stipulated scenario; excludes uncertainty about true effectiveness',
        'family_limitation':'Domains are strata, not independent repository families; future related tasks require family-cluster resampling',
        'retry_accounting':'Synthetic attempts; total tokens already include retry allowances; never multiply aggregate tokens by attempts again',
        'summaries':summaries,'effects':effects}
    (args.output/'metrics.json').write_text(json.dumps(report,indent=2,allow_nan=False)+'\n')
    lines=['# Synthetic projection: computed comparison tables\n',
        '**Table 1: Synthetic Benchmark Projection & Ablation Model (N=120).**\n',
        '| Config | Visible successes; % [95% Wilson CI] | Hidden successes; % [95% Wilson CI] | Mean attempts | Runtime s, mean ± SD | API USD | Host USD | Total USD | USD/hidden-correct |',
        '|---|---|---|---:|---:|---:|---:|---:|---:|']
    for r in summaries:
        lines.append(f"| {r['config_id']} | {r['visible_successes']}/120; {100*r['visible_rate']:.1f} [{100*r['visible_ci_low']:.1f}, {100*r['visible_ci_high']:.1f}] | {r['hidden_successes']}/120; {100*r['hidden_rate']:.1f} [{100*r['hidden_ci_low']:.1f}, {100*r['hidden_ci_high']:.1f}] | {r['mean_repair_attempts']:.2f} | {r['runtime_mean']:.1f} ± {r['runtime_sd']:.1f} | {r['api_cost_total']:.4f} | {r['host_cost_total']:.4f} | {r['failure_inclusive_cost_total']:.4f} | {r['failure_inclusive_cost_per_hidden_correct']:.5f} |")
    lines += ['\n**Table 2: Synthetic Benchmark Projection & Ablation Model (N=120). Primary paired contrasts.**\n',
        '| Contrast | Hidden difference, pp [bootstrap 95% CI] | Cliff delta [bootstrap 95% CI] | B6-only / baseline-only / both / neither |',
        '|---|---|---|---|']
    for e in effects:
        lo,hi=e['paired_stratified_bootstrap_95'];dl,dh=e['cliffs_delta_paired_stratified_bootstrap_95']
        lines.append(f"| {e['contrast']} | {100*e['risk_difference']:.1f} [{100*lo:.1f}, {100*hi:.1f}] | {e['cliffs_delta']:.3f} [{dl:.3f}, {dh:.3f}] | {e['full_only']} / {e['baseline_only']} / {e['both_correct']} / {e['neither_correct']} |")
    (args.output/'tables.md').write_text('\n'.join(lines)+'\n',encoding='utf-8')
    print(json.dumps({'synthetic_records':len(frame),'output':str(args.output),'effects':effects},indent=2))

if __name__=='__main__':main()
