# Synthetic projection: computed comparison tables

**Table 1: Synthetic Benchmark Projection & Ablation Model (N=120).**

| Config | Visible successes; % [95% Wilson CI] | Hidden successes; % [95% Wilson CI] | Mean attempts | Runtime s, mean ± SD | API USD | Host USD | Total USD | USD/hidden-correct |
|---|---|---|---:|---:|---:|---:|---:|---:|
| B1 | 76/120; 63.3 [54.4, 71.4] | 26/120; 21.7 [15.2, 29.9] | 1.00 | 42.0 ± 18.0 | 0.4995 | 0.1302 | 0.6297 | 0.02422 |
| B2 | 90/120; 75.0 [66.6, 81.9] | 34/120; 28.3 [21.0, 37.0] | 1.60 | 64.0 ± 26.0 | 0.6120 | 0.1984 | 0.8104 | 0.02384 |
| B3 | 93/120; 77.5 [69.2, 84.1] | 36/120; 30.0 [22.5, 38.7] | 1.50 | 70.0 ± 25.0 | 0.7200 | 0.2170 | 0.9370 | 0.02603 |
| B4 | 100/120; 83.3 [75.7, 88.9] | 62/120; 51.7 [42.8, 60.4] | 1.45 | 93.0 ± 34.0 | 0.8325 | 0.2883 | 1.1208 | 0.01808 |
| B5 | 105/120; 87.5 [80.4, 92.3] | 87/120; 72.5 [63.9, 79.7] | 1.35 | 112.0 ± 40.0 | 0.9540 | 0.3472 | 1.3012 | 0.01496 |
| B6 | 111/120; 92.5 [86.4, 96.0] | 97/120; 80.8 [72.9, 86.9] | 1.25 | 128.0 ± 47.0 | 1.1610 | 0.3968 | 1.5578 | 0.01606 |

**Table 2: Synthetic Benchmark Projection & Ablation Model (N=120). Primary paired contrasts.**

| Contrast | Hidden difference, pp [bootstrap 95% CI] | Cliff delta [bootstrap 95% CI] | B6-only / baseline-only / both / neither |
|---|---|---|---|
| B6-B2 | 52.5 [42.5, 62.5] | 0.525 [0.425, 0.625] | 67 / 4 / 30 / 19 |
| B6-B3 | 50.8 [40.8, 60.8] | 0.508 [0.408, 0.608] | 66 / 5 / 31 / 18 |
