# Evaluation and Statistical Treatment

The current 120-task by six-configuration dataset is a synthetic benchmark projection used to validate the reporting layout and analysis pipeline. It contains 720 constructed records, not 720 executed repairs. The actual inference diagnostics did not execute candidate tests; the four authored qualification fixtures exercise instrumentation only. All following numerical comparisons are conditional on the stipulated synthetic scenario.

## Estimands and uncertainty

Visible success is passage of the public test suite. Independent correctness requires visible success and passage of every applicable hidden behavioral assertion. Abstentions, syntax errors and evaluated repair failures remain in the denominator of the eventual failure-inclusive end-to-end repair estimand. Infrastructure failures require separately reported intention-to-run and evaluable-run summaries; unexecuted hidden tests are not coded as observed hidden failures. The current synthetic scenario stipulates completed outcomes for all 120 tasks per treatment and does not estimate infrastructure availability.

For a binary rate p-hat = k/n, the 95% Wilson interval uses z = Phi-inverse(0.975), center (p-hat + z squared/(2n))/(1 + z squared/n), and half-width z sqrt(p-hat(1-p-hat)/n + z squared/(4n squared))/(1 + z squared/n). Intervals in the generated table describe hypothetical independent Bernoulli observations conditional on the synthetic counts. They do not include uncertainty about the assumed effect size or model specification.

Primary contrasts are B6 versus B2 and B6 versus B3. A paired bootstrap resamples the same task indices for both treatments, separately within the four domain strata, preserving the original 30-task stratum sizes. We use 20,000 draws and seed 42, and report percentile intervals. These strata are not independent repository families. The eventual empirical corpus must identify related task families and use family-cluster resampling when variants share a source repository, template or migration; the current layout cannot supply that missing empirical grouping.

Cliff's delta is P(X > Y) - P(X < Y), where X is B6 hidden correctness and Y is the comparator. We compute the marginal all-pairs ordinal effect and preserve task pairing in its bootstrap. For binary X and Y, delta = p_B6 - p_baseline; its numerical equality to the risk difference is algebraic, not independent corroboration. No inferential p-value or superiority claim is derived from the deliberately constructed outcomes. If confirmatory hypothesis tests are later used for both prespecified contrasts, their multiplicity policy must be fixed before inspecting empirical outcomes.

The B6-B2 contrast is 52.5 percentage points, with a conditional paired bootstrap interval of 42.5-62.5 points and Cliff's delta 0.525 [0.425, 0.625]. B6-B3 is 50.8 points [40.8, 60.8], with delta 0.508 [0.408, 0.608]. B6 loses four tasks that B2 passes and five that B3 passes, so the construction does not impose per-task dominance. The six treatments' complete Wilson intervals and cost accounting appear in analysis/tables.md.

## Failure-inclusive cost accounting

The outcome records contain aggregate prompt and completion/reasoning tokens for every modeled attempt and model stage. For cost accounting we specify synthetic mean repair-attempt counts of 1.00, 1.60, 1.50, 1.45, 1.35 and 1.25 for B1-B6. B1 has no ordinary-test retry loop. These are additional explicit scenario assumptions, not recovered live retry measurements. The script assigns the additional attempts to longer modeled tasks and writes the accounting rows. Token totals are never multiplied by the attempt count again: doing so would double-charge the retry allowance.

Let I_j and O_j be aggregate billed input and output/reasoning tokens for task j, and T_j its wall time. At the declared rate card, API_j = (0.75 I_j + 3.75 O_j)/1,000,000 USD. The modeled host allocation is (0.08 + 0.065 x 0.20) T_j/3600 USD, combining reserved capacity at USD 0.08/hour and an assumed 65 W host at USD 0.20/kWh. The host allocation covers waiting and evaluation time. No GPU telemetry, cloud energy, human review, tax or deployment fee is inferred from these assumptions.

Failure-inclusive cost per correct repair is sum_j(API_j + Host_j) / sum_j Correct_j. Thus spending on unsuccessful repairs remains in the numerator. The synthetic six-configuration matrix costs USD 4.7790 for API tokens and USD 6.3569 with the stipulated host allocation. B5 has the lowest modeled cost per hidden-correct repair (USD 0.01496), while B6 has the highest hidden correctness (97/120) at USD 0.01606 per correct repair. This is a constructed tradeoff, not an empirical billing result.

The rate card is tied to global Gemini 3.8 Flash introductory prices through 31 December 2026. Reprice all retained usage when the tariff changes; do not present estimated list-price charges as invoices. Source: https://cloud.google.com/gemini-enterprise-agent-platform/generative-ai/pricing .

## Interpretation and boundaries

The proposed APIShield question is whether structural/semantic context and inferred checks jointly improve migration correctness over documentation and ordinary test feedback. The synthetic matrix encodes that hypothesis and also encodes diminishing marginal benefits, residual incorrect patches and additional compute. It does not answer the question. Replacing projections with findings requires the held-out task implementations, an independent final-only oracle, the container-executed candidates, complete model and failure logs, and the planned open-weight replication. Cross-model generality, production readiness and a camera-ready empirical claim remain unestablished.
