# Venue integration and publication metadata

Primary layout target: ACM Transactions on Software Engineering and Methodology (TOSEM). Alternative layout target: IEEE Transactions on Software Engineering (TSE). These are separate rendering profiles; a manuscript should be submitted to one venue at a time under its applicable policies.

The manuscript is currently a synthetic evaluation walkthrough and artifact-methods draft, not a completed empirical submission or accepted camera-ready paper. Author identities, affiliations, corresponding-author details and ORCIDs have not been supplied. The source therefore uses an explicitly anonymous author block and assigns no fictional authors or institutions. Anonymous layout does not imply that a particular venue mandates anonymous review.

TOSEM source: `manuscript/tosem-review.tex`, using acmart in manuscript/review/anonymous mode and the TOSEM journal identifier. Production layout can use acmsmall after the venue's author kit is confirmed. ACM's publication template guidance identifies acmsmall as the usual journal style and manuscript as the review layout. Publisher-generated DOI, copyright, article number, issue, acceptance dates and rights metadata are deliberately not invented. Source: https://www.acm.org/binaries/content/assets/publications/taps/latex-best_practices-06-may-2020.pdf . The live journal-specific guidelines could not be fetched during preparation; recheck them before submission rather than treating this profile as an author-kit certification.

TSE source: `manuscript/tse-review.tex`, using IEEEtran's journal/compsoc profile. IEEE directs journal authors to its template selector. Confirm the current TSE-specific author kit before final production; no current page limit, acceptance status or publication fee is asserted here. Source: https://journals.ieeeauthorcenter.ieee.org/create-your-ieee-journal-article/authoring-tools-and-templates/ .

Target ACM CCS descriptions:

- Software and its engineering → Software maintenance tools.
- Software and its engineering → Automatic programming.
- Software and its engineering → Software testing and debugging.

These are target textual descriptions. Production CCS identifiers/XML should be exported from ACM's classifier when submitting; unverified numeric concept IDs are not fabricated. Both requested core descriptions are included through acmart's ccsdesc commands.

Keywords: API migration; automated program repair; semantic code graphs; behavioral invariant inference; large language models; empirical software engineering.

Recommended master structure: Introduction; Background and Related Work; System and Research Hypotheses; Benchmark and Oracle Construction; Experimental Design and Cost Accounting; Results and Ablation Analysis; Threats to Validity; Artifact Availability; Conclusion. The supplied venue files compile the completed evaluation, positioning and appendix material as a self-contained review supplement. They do not masquerade as a complete accepted article containing unprovided empirical sections.

No TeX compiler was available during preparation. Venue sources and generated tables are provided, but a successful PDF compilation is not claimed. The ordinary shell build commands are `latexmk -pdf tosem-review.tex` or `latexmk -pdf tse-review.tex`, run from the manuscript directory after installing the relevant publisher classes and BibTeX styles.
