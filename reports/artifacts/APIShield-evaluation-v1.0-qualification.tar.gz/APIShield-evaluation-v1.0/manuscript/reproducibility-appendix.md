# Artifact and Reproducibility Appendix

## Archive scope and availability

The local archive is named APIShield-evaluation-v1.0.tar.gz. Version 1.0 identifies this package revision, not completion of the empirical evaluation. It contains a synthetic 120-task/six-treatment layout dataset, actual inference diagnostics, four executable authored qualification tasks, scripts, schemas and publication sources. No DOI, public repository release, artifact badge, verified immutable model snapshot or clean artifact commit has been assigned. Licensing and third-party redistribution permissions require owner confirmation before public archival; this package makes no new license grant.

The full payload is enumerated in DIRECTORY_MANIFEST.txt and hashed in MANIFEST.json. Every payload member has SHA-256, MD5 and byte-size records. MANIFEST.json excludes itself to avoid circular hashing. The external archive sidecars verify the compressed tarball. These hashes identify the local working-file snapshot; the recorded existing Git HEAD alone does not identify the uncommitted artifact.

## Directory and evidence separation

The archive extracts into APIShield-evaluation-v1.0/. Its directories are:

| Directory or file | Contents and interpretation |
|---|---|
| README.md | Scope, tested commands, environment and remaining limits |
| ARCHIVE_STATUS.json | Package version and observed provenance; no invented publication identifiers |
| schemas/ | Version-1.0 normalized record schema, actual prompt-prefix templates and original task schema |
| data/synthetic/ | 720 constructed outcome rows, 360 applicable financial-invariant rows, scenario parameters and dataset seed |
| data/observed/ | Six normalized actual inference records, with hidden status NOT_EVALUATED |
| data/qualification/ | 24 normalized authored-fixture qualification records; these are not LLM effectiveness evidence |
| benchmarks/runs/gemini_bank014_observed_20261015*/ | Eighteen original diagnostic task/configuration traces, including timeouts; instantiated prompts, provider responses and candidate diffs where produced |
| benchmarks/runs/qualification_verified/ | Original authored-fixture traces and test evidence |
| benchmarks/tasks/ | Four runnable public task fixtures and contracts |
| benchmarks/evaluator_private/ | Separate hidden assertions, hidden vectors and reference patches, never used as generation context |
| benchmarks/fixture_candidates/ | Authored qualification candidates, distinct from actual model-produced candidates |
| benchmarks/harness/, runners/, adapters/, docker/ | Original headless research code, execution workers and container boundary |
| benchmarks/profiles/ | Exact requested model IDs, known weight fingerprints, rate card and observed hardware status |
| apishield/, config.py | Controller modules required by the retained live adapter; no frontend is launched |
| scripts/ | Analysis, portable single-case execution, payload verification and tarball construction |
| analysis/ | Recomputed synthetic tables, metrics, CSV comparison and explicit retry accounting |
| manuscript/ | Fully written inclusion sections, shared author macros and TOSEM/TSE review sources |
| references/ | Twelve BibTeX references and retrieved registration metadata |

Only four task IDs denote executable qualification fixtures: TASK-BANK-014, TASK-BANK-015, TASK-SHIP-029 and TASK-PAY-008. The 120 SYN-prefixed task IDs denote constructed scenario records and are not executable benchmark implementations. No candidate diffs or execution logs are fabricated for those 120 synthetic tasks.

The synthetic dataset has shared generation seed 20261015. There were no independent per-task random streams; task_seeds.json says so explicitly. The paired bootstrap uses seed 42. Existing qualification inputs are authored deterministic vectors rather than randomly seeded samples. Prompt templates preserve the actual prefixes from the harness; complete instantiated requests are retained in their original evidence directories.

## Exact reproduction commands

The following commands target a POSIX shell after extracting the archive. Python 3.13 and pip are required. Dependency installation may use the network; candidate evaluation uses network-disabled containers. Analysis and authored-fixture reproduction do not require cloud credentials or a GPU.

```bash
tar -xzf APIShield-evaluation-v1.0.tar.gz
cd APIShield-evaluation-v1.0

# 1. Environment and payload verification
python3 -c 'import sys; assert sys.version_info[:2] == (3, 13), sys.version'
python3 -m venv .venv
.venv/bin/python -m pip install -r benchmarks/requirements-analysis.txt
.venv/bin/python scripts/verify_environment.py

# 2. Reproduction of analysis and tables from the labelled synthetic raw records
.venv/bin/python scripts/analyze.py --output analysis-reproduced
diff -u analysis/comparison.csv analysis-reproduced/comparison.csv
diff -u analysis/metrics.json analysis-reproduced/metrics.json

# 3. Single-case headless qualification; an authored fixture, not a live AI run
CASE_OUTPUT="$(mktemp -d)/case"
.venv/bin/python scripts/headless.py --mode fixture --task TASK-BANK-014 --config B6 --output "$CASE_OUTPUT"
```

Fixture B6 uses an authored candidate and is allowed to run as trusted qualification code. A future model-generated candidate requires Docker: the live wrapper refuses host execution. It also requires explicit --execute-live, a content-addressed --image, --allow-unpinned-provider for the currently unverified immutable identity, and a managed JSON service account outside the archive. No credential is packaged. Docker engine availability, OS isolation and GPU inference must be checked on the migration host; local preparation did not establish them.

The package-local headless wrapper rebases original Windows task paths to the extraction directory. A fresh output directory prevents overwriting retained records. Tarball extraction outside Git does not manufacture a commit anchor: a new run's tool_commit may be null, while MANIFEST.json continues to identify its archived source bytes.

## Experiment-record fields and semantics

The executable schema is schemas/experiment-record.schema.json (JSON Schema draft 2020-12, version 1.0). Original 56-column records remain intact; normalized records add explicit evidence typing rather than rewriting observations.

| Field | Type and rule |
|---|---|
| task_id | Nonempty string; SYN-prefixed scenario IDs are distinguished from TASK-prefixed executable fixtures |
| config_id | Exactly B1, B2, B3, B4, B5 or B6 |
| model_requested | Actual request model ID, or null when no model was invoked |
| model_resolved_snapshot | Object with provider_returned_id, immutable_verified and identity_kind, or null when unobserved; a returned version ID is never silently upgraded to an immutable snapshot |
| git_commit_sha | Forty-character lowercase Git SHA, or null outside Git; accompanied by git_commit_identifies_run |
| runtime_s | Nonnegative measured or modeled seconds, interpreted according to evidence_kind |
| prompt_tokens | Nonnegative aggregate input tokens, or null when unavailable |
| completion_tokens | Nonnegative aggregate output plus reasoning tokens, or null when unavailable |
| repair_attempts | Positive integer or null when unknown; contextual model calls are separately retained in original call logs |
| token_accounting | Explicit measured aggregate, synthetic retry-inclusive allowance, no model invoked, or unknown transport usage |
| hidden_invariants_status | evaluated boolean plus a named boolean check map; unexecuted assertions use evaluated=false and an empty map, not invented failures or passes |
| oracle_verdict | PASS, FAIL, NOT_EVALUATED or EXECUTION_ERROR |
| evidence_kind | synthetic_projection, live_inference or fixture_replay |
| original_record_path | Exact archive-relative path to the source record |

The actual observed B6 record requests and returns gemini-3.8-flash, records 1,957 prompt tokens and 523 completion/reasoning tokens, and has runtime 22.5286683 s. Its oracle verdict is NOT_EVALUATED. Its returned identifier has immutable_verified=false. The recorded Git HEAD is 80e7bbe0c01b58fa6615098c1bc56c6534a830eb, with git_commit_identifies_run=false because the source was uncommitted. These distinctions must remain visible when records are reused.

## Isolation and remaining archival work

Candidate workers receive candidate files and input vectors; public and hidden oracle code execute in separate evaluator processes/containers and do not import candidate Python. Hidden results are final-only and never become retry feedback. Docker configuration requests a non-root UID, no network, read-only root, dropped capabilities, no-new-privileges, CPU/memory/PID limits and bounded runtime/output. Configuration validation is not evidence that those OS controls executed successfully on the current machine.

Before empirical publication, supply the actual 120 executable held-out tasks, independent oracle audit, complete evaluated model traces, open-weight replication and telemetry, confirmed author identities, a clean source release, a chosen license, a persistent archive deposit and the resulting real DOI. This appendix records the current local package accurately; none of those outstanding fields is replaced by a fictional identifier.
