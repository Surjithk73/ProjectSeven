# APIShield evaluation manuscript: complete review inclusion package

**Synthetic projection and actual diagnostic evidence remain separate. This is not a completed empirical camera-ready manuscript.**

# Evaluation and Statistical Treatment

The current 120-task by six-configuration dataset is a synthetic benchmark projection used to validate the reporting layout and analysis pipeline. It contains 720 constructed records, not 720 executed repairs. The actual inference diagnostics did not execute candidate tests; the four authored qualification fixtures exercise instrumentation only. All following numerical comparisons are conditional on the stipulated synthetic scenario.

## Estimands and uncertainty

Visible success is passage of the public test suite. Independent correctness requires visible success and passage of every applicable hidden behavioral assertion. Abstentions, syntax errors and evaluated repair failures remain in the denominator of the eventual failure-inclusive end-to-end repair estimand. Infrastructure failures require separately reported intention-to-run and evaluable-run summaries; unexecuted hidden tests are not coded as observed hidden failures. The current synthetic scenario stipulates completed outcomes for all 120 tasks per treatment and does not estimate infrastructure availability.

For a binary rate p-hat = k/n, the 95% Wilson interval uses z = Phi-inverse(0.975), center (p-hat + z squared/(2n))/(1 + z squared/n), and half-width z sqrt(p-hat(1-p-hat)/n + z squared/(4n squared))/(1 + z squared/n). Intervals in the generated table describe hypothetical independent Bernoulli observations conditional on the synthetic counts. They do not include uncertainty about the assumed effect size or model specification.

Primary contrasts are B6 versus B2 and B6 versus B3. A paired bootstrap resamples the same task indices for both treatments, separately within the four domain strata, preserving the original 30-task stratum sizes. We use 20,000 draws and seed 42, and report percentile intervals. These strata are not independent repository families. The eventual empirical corpus must identify related task families and use family-cluster resampling when variants share a source repository, template or migration; the current layout cannot supply that missing empirical grouping.

Cliff's delta is P(X > Y) - P(X < Y), where X is B6 hidden correctness and Y is the comparator. We compute the marginal all-pairs ordinal effect and preserve task pairing in its bootstrap. For binary X and Y, delta = p_B6 - p_baseline; its numerical equality to the risk difference is algebraic, not independent corroboration. No inferential p-value or superiority claim is derived from the deliberately constructed outcomes. If confirmatory hypothesis tests are later used for both prespecified contrasts, their multiplicity policy must be fixed before inspecting empirical outcomes.

The B6-B2 contrast is 52.5 percentage points, with a conditional paired bootstrap interval of 42.5-62.5 points and Cliff's delta 0.525 [0.425, 0.625]. B6-B3 is 50.8 points [40.8, 60.8], with delta 0.508 [0.408, 0.608]. B6 loses four tasks that B2 passes and five that B3 passes, so the construction does not impose per-task dominance. The six treatments' complete Wilson intervals and cost accounting appear in analysis/tables.md.

## Failure-inclusive cost accounting

The outcome records contain aggregate prompt and completion/reasoning tokens for every modeled attempt and model stage. For cost accounting we specify synthetic mean repair-attempt counts of 1.00, 1.60, 1.50, 1.45, 1.35 and 1.25 for B1-B6. B1 has no ordinary-test retry loop. These are additional explicit scenario assumptions, not recovered live retry measurements. The script assigns the additional attempts to longer modeled tasks and writes the accounting rows. Token totals are never multiplied by the attempt count again: doing so would double-charge the retry allowance.

Let I_j and O_j be aggregate billed input and output/reasoning tokens for task j, and T_j its wall time. At the declared rate card, API_j = (0.75 I_j + 3.75 O_j)/1,000,000 USD. The modeled host allocation is (0.08 + 0.065 x 0.20) T_j/3600 USD, combining reserved capacity at USD 0.08/hour and an assumed 65 W host at USD 0.20/kWh. The host allocation covers waiting and evaluation time. No GPU telemetry, cloud energy, human review, tax or deployment fee is inferred from these assumptions.

Failure-inclusive cost per correct repair is sum_j(API_j + Host_j) / sum_j Correct_j. Thus spending on unsuccessful repairs remains in the numerator. The synthetic six-configuration matrix costs USD 4.7790 for API tokens and USD 6.3569 with the stipulated host allocation. B5 has the lowest modeled cost per hidden-correct repair (USD 0.01496), while B6 has the highest hidden correctness (97/120) at USD 0.01606 per correct repair. This is a constructed tradeoff, not an empirical billing result.

The rate card is tied to global Gemini 3.8 Flash introductory prices through 31 December 2026. Reprice all retained usage when the tariff changes; do not present estimated list-price charges as invoices. Source: https://cloud.google.com/gemini-enterprise-agent-platform/generative-ai/pricing .

## Interpretation and boundaries

The proposed APIShield question is whether structural/semantic context and inferred checks jointly improve migration correctness over documentation and ordinary test feedback. The synthetic matrix encodes that hypothesis and also encodes diminishing marginal benefits, residual incorrect patches and additional compute. It does not answer the question. Replacing projections with findings requires the held-out task implementations, an independent final-only oracle, the container-executed candidates, complete model and failure logs, and the planned open-weight replication. Cross-model generality, production readiness and a camera-ready empirical claim remain unestablished.


# Synthetic projection: computed comparison tables

**Table 1: Synthetic Benchmark Projection & Ablation Model (N=120).**

| Config | Visible successes; % [95% Wilson CI] | Hidden successes; % [95% Wilson CI] | Mean attempts | Runtime s, mean ± SD | API USD | Host USD | Total USD | USD/hidden-correct |
|---|---|---|---:|---:|---:|---:|---:|---:|
| B1 | 76/120; 63.3 [54.4, 71.4] | 26/120; 21.7 [15.2, 29.9] | 1.00 | 42.0 ± 18.0 | 0.4995 | 0.1302 | 0.6297 | 0.02422 |
| B2 | 90/120; 75.0 [66.6, 81.9] | 34/120; 28.3 [21.0, 37.0] | 1.60 | 64.0 ± 26.0 | 0.6120 | 0.1984 | 0.8104 | 0.02384 |
| B3 | 93/120; 77.5 [69.2, 84.1] | 36/120; 30.0 [22.5, 38.7] | 1.50 | 70.0 ± 25.0 | 0.7200 | 0.2170 | 0.9370 | 0.02603 |
| B4 | 100/120; 83.3 [75.7, 88.9] | 62/120; 51.7 [42.8, 60.4] | 1.45 | 93.0 ± 34.0 | 0.8325 | 0.2883 | 1.1208 | 0.01808 |
| B5 | 105/120; 87.5 [80.4, 92.3] | 87/120; 72.5 [63.9, 79.7] | 1.35 | 112.0 ± 40.0 | 0.9540 | 0.3472 | 1.3012 | 0.01496 |
| B6 | 111/120; 92.5 [86.4, 96.0] | 97/120; 80.8 [72.9, 86.9] | 1.25 | 128.0 ± 47.0 | 1.1610 | 0.3968 | 1.5578 | 0.01606 |

**Table 2: Synthetic Benchmark Projection & Ablation Model (N=120). Primary paired contrasts.**

| Contrast | Hidden difference, pp [bootstrap 95% CI] | Cliff delta [bootstrap 95% CI] | B6-only / baseline-only / both / neither |
|---|---|---|---|
| B6-B2 | 52.5 [42.5, 62.5] | 0.525 [0.425, 0.625] | 67 / 4 / 30 / 19 |
| B6-B3 | 50.8 [40.8, 60.8] | 0.508 [0.408, 0.608] | 66 / 5 / 31 / 18 |


# Artifact and Reproducibility Appendix

## Archive scope and availability

The local archive is named APIShield-evaluation-v1.0.tar.gz. Version 1.0 identifies this package revision, not completion of the empirical evaluation. It contains a synthetic 120-task/six-treatment layout dataset, actual inference diagnostics, four executable authored qualification tasks, scripts, schemas and publication sources. No DOI, public repository release, artifact badge, verified immutable model snapshot or clean artifact commit has been assigned. Licensing and third-party redistribution permissions require owner confirmation before public archival; this package makes no new license grant.

The full payload is enumerated in DIRECTORY_MANIFEST.txt and hashed in MANIFEST.json. Every payload member has SHA-256, MD5 and byte-size records. MANIFEST.json excludes itself to avoid circular hashing. The external archive sidecars verify the compressed tarball. These hashes identify the local working-file snapshot; the recorded existing Git HEAD alone does not identify the uncommitted artifact.

## Directory and evidence separation

The archive extracts into APIShield-evaluation-v1.0/. Its directories are:

| Directory or file | Contents and interpretation |
|---|---|
| README.md | Scope, tested commands, environment and remaining limits |
| ARCHIVE_STATUS.json | Package version and observed provenance; no invented publication identifiers |
| schemas/ | Version-1.0 normalized record schema, actual prompt-prefix templates and original task schema |
| data/synthetic/ | 720 constructed outcome rows, 360 applicable financial-invariant rows, scenario parameters and dataset seed |
| data/observed/ | Six normalized actual inference records, with hidden status NOT_EVALUATED |
| data/qualification/ | 24 normalized authored-fixture qualification records; these are not LLM effectiveness evidence |
| benchmarks/runs/gemini_bank014_observed_20261015*/ | Eighteen original diagnostic task/configuration traces, including timeouts; instantiated prompts, provider responses and candidate diffs where produced |
| benchmarks/runs/qualification_verified/ | Original authored-fixture traces and test evidence |
| benchmarks/tasks/ | Four runnable public task fixtures and contracts |
| benchmarks/evaluator_private/ | Separate hidden assertions, hidden vectors and reference patches, never used as generation context |
| benchmarks/fixture_candidates/ | Authored qualification candidates, distinct from actual model-produced candidates |
| benchmarks/harness/, runners/, adapters/, docker/ | Original headless research code, execution workers and container boundary |
| benchmarks/profiles/ | Exact requested model IDs, known weight fingerprints, rate card and observed hardware status |
| apishield/, config.py | Controller modules required by the retained live adapter; no frontend is launched |
| scripts/ | Analysis, portable single-case execution, payload verification and tarball construction |
| analysis/ | Recomputed synthetic tables, metrics, CSV comparison and explicit retry accounting |
| manuscript/ | Fully written inclusion sections, shared author macros and TOSEM/TSE review sources |
| references/ | Twelve BibTeX references and retrieved registration metadata |

Only four task IDs denote executable qualification fixtures: TASK-BANK-014, TASK-BANK-015, TASK-SHIP-029 and TASK-PAY-008. The 120 SYN-prefixed task IDs denote constructed scenario records and are not executable benchmark implementations. No candidate diffs or execution logs are fabricated for those 120 synthetic tasks.

The synthetic dataset has shared generation seed 20261015. There were no independent per-task random streams; task_seeds.json says so explicitly. The paired bootstrap uses seed 42. Existing qualification inputs are authored deterministic vectors rather than randomly seeded samples. Prompt templates preserve the actual prefixes from the harness; complete instantiated requests are retained in their original evidence directories.

## Exact reproduction commands

The following commands target a POSIX shell after extracting the archive. Python 3.13 and pip are required. Dependency installation may use the network; candidate evaluation uses network-disabled containers. Analysis and authored-fixture reproduction do not require cloud credentials or a GPU.

```bash
tar -xzf APIShield-evaluation-v1.0.tar.gz
cd APIShield-evaluation-v1.0

# 1. Environment and payload verification
python3 -c 'import sys; assert sys.version_info[:2] == (3, 13), sys.version'
python3 -m venv .venv
.venv/bin/python -m pip install -r benchmarks/requirements-analysis.txt
.venv/bin/python scripts/verify_environment.py

# 2. Reproduction of analysis and tables from the labelled synthetic raw records
.venv/bin/python scripts/analyze.py --output analysis-reproduced
diff -u analysis/comparison.csv analysis-reproduced/comparison.csv
diff -u analysis/metrics.json analysis-reproduced/metrics.json

# 3. Single-case headless qualification; an authored fixture, not a live AI run
CASE_OUTPUT="$(mktemp -d)/case"
.venv/bin/python scripts/headless.py --mode fixture --task TASK-BANK-014 --config B6 --output "$CASE_OUTPUT"
```

Fixture B6 uses an authored candidate and is allowed to run as trusted qualification code. A future model-generated candidate requires Docker: the live wrapper refuses host execution. It also requires explicit --execute-live, a content-addressed --image, --allow-unpinned-provider for the currently unverified immutable identity, and a managed JSON service account outside the archive. No credential is packaged. Docker engine availability, OS isolation and GPU inference must be checked on the migration host; local preparation did not establish them.

The package-local headless wrapper rebases original Windows task paths to the extraction directory. A fresh output directory prevents overwriting retained records. Tarball extraction outside Git does not manufacture a commit anchor: a new run's tool_commit may be null, while MANIFEST.json continues to identify its archived source bytes.

## Experiment-record fields and semantics

The executable schema is schemas/experiment-record.schema.json (JSON Schema draft 2020-12, version 1.0). Original 56-column records remain intact; normalized records add explicit evidence typing rather than rewriting observations.

| Field | Type and rule |
|---|---|
| task_id | Nonempty string; SYN-prefixed scenario IDs are distinguished from TASK-prefixed executable fixtures |
| config_id | Exactly B1, B2, B3, B4, B5 or B6 |
| model_requested | Actual request model ID, or null when no model was invoked |
| model_resolved_snapshot | Object with provider_returned_id, immutable_verified and identity_kind, or null when unobserved; a returned version ID is never silently upgraded to an immutable snapshot |
| git_commit_sha | Forty-character lowercase Git SHA, or null outside Git; accompanied by git_commit_identifies_run |
| runtime_s | Nonnegative measured or modeled seconds, interpreted according to evidence_kind |
| prompt_tokens | Nonnegative aggregate input tokens, or null when unavailable |
| completion_tokens | Nonnegative aggregate output plus reasoning tokens, or null when unavailable |
| repair_attempts | Positive integer or null when unknown; contextual model calls are separately retained in original call logs |
| token_accounting | Explicit measured aggregate, synthetic retry-inclusive allowance, no model invoked, or unknown transport usage |
| hidden_invariants_status | evaluated boolean plus a named boolean check map; unexecuted assertions use evaluated=false and an empty map, not invented failures or passes |
| oracle_verdict | PASS, FAIL, NOT_EVALUATED or EXECUTION_ERROR |
| evidence_kind | synthetic_projection, live_inference or fixture_replay |
| original_record_path | Exact archive-relative path to the source record |

The actual observed B6 record requests and returns gemini-3.8-flash, records 1,957 prompt tokens and 523 completion/reasoning tokens, and has runtime 22.5286683 s. Its oracle verdict is NOT_EVALUATED. Its returned identifier has immutable_verified=false. The recorded Git HEAD is 80e7bbe0c01b58fa6615098c1bc56c6534a830eb, with git_commit_identifies_run=false because the source was uncommitted. These distinctions must remain visible when records are reused.

## Isolation and remaining archival work

Candidate workers receive candidate files and input vectors; public and hidden oracle code execute in separate evaluator processes/containers and do not import candidate Python. Hidden results are final-only and never become retry feedback. Docker configuration requests a non-root UID, no network, read-only root, dropped capabilities, no-new-privileges, CPU/memory/PID limits and bounded runtime/output. Configuration validation is not evidence that those OS controls executed successfully on the current machine.

Before empirical publication, supply the actual 120 executable held-out tasks, independent oracle audit, complete evaluated model traces, open-weight replication and telemetry, confirmed author identities, a clean source release, a chosen license, a persistent archive deposit and the resulting real DOI. This appendix records the current local package accurately; none of those outstanding fields is replaced by a fictional identifier.


# Venue integration and publication metadata

Primary layout target: ACM Transactions on Software Engineering and Methodology (TOSEM). Alternative layout target: IEEE Transactions on Software Engineering (TSE). These are separate rendering profiles; a manuscript should be submitted to one venue at a time under its applicable policies.

The manuscript is currently a synthetic evaluation walkthrough and artifact-methods draft, not a completed empirical submission or accepted camera-ready paper. Author identities, affiliations, corresponding-author details and ORCIDs have not been supplied. The source therefore uses an explicitly anonymous author block and assigns no fictional authors or institutions. Anonymous layout does not imply that a particular venue mandates anonymous review.

TOSEM source: `manuscript/tosem-review.tex`, using acmart in manuscript/review/anonymous mode and the TOSEM journal identifier. Production layout can use acmsmall after the venue's author kit is confirmed. ACM's publication template guidance identifies acmsmall as the usual journal style and manuscript as the review layout. Publisher-generated DOI, copyright, article number, issue, acceptance dates and rights metadata are deliberately not invented. Source: https://www.acm.org/binaries/content/assets/publications/taps/latex-best_practices-06-may-2020.pdf . The live journal-specific guidelines could not be fetched during preparation; recheck them before submission rather than treating this profile as an author-kit certification.

TSE source: `manuscript/tse-review.tex`, using IEEEtran's journal/compsoc profile. IEEE directs journal authors to its template selector. Confirm the current TSE-specific author kit before final production; no current page limit, acceptance status or publication fee is asserted here. Source: https://journals.ieeeauthorcenter.ieee.org/create-your-ieee-journal-article/authoring-tools-and-templates/ .

Target ACM CCS descriptions:

- Software and its engineering → Software maintenance tools.
- Software and its engineering → Automatic programming.
- Software and its engineering → Software testing and debugging.

These are target textual descriptions. Production CCS identifiers/XML should be exported from ACM's classifier when submitting; unverified numeric concept IDs are not fabricated. Both requested core descriptions are included through acmart's ccsdesc commands.

Keywords: API migration; automated program repair; semantic code graphs; behavioral invariant inference; large language models; empirical software engineering.

Recommended master structure: Introduction; Background and Related Work; System and Research Hypotheses; Benchmark and Oracle Construction; Experimental Design and Cost Accounting; Results and Ablation Analysis; Threats to Validity; Artifact Availability; Conclusion. The supplied venue files compile the completed evaluation, positioning and appendix material as a self-contained review supplement. They do not masquerade as a complete accepted article containing unprovided empirical sections.

No TeX compiler was available during preparation. Venue sources and generated tables are provided, but a successful PDF compilation is not claimed. The ordinary shell build commands are `latexmk -pdf tosem-review.tex` or `latexmk -pdf tse-review.tex`, run from the manuscript directory after installing the relevant publisher classes and BibTeX styles.


# Related Work and Scope of Contribution

APIShield concerns client-side adaptation to API contract changes. Its research question is whether structural localization, inferred semantic relationships and inferred behavioral checks jointly improve migration correctness beyond code, documentation and ordinary test feedback. The present synthetic layout provides no evidence of such an improvement; the question remains for the controlled evaluation.

**Specification-grounded REST repair.** Yamagishi et al.'s dcFix detects client fragments inconsistent with REST specifications and supplies localized code and specification context to an LLM [dcfix2025]. It is consequently a close comparator, not a basis for claiming that specification-aware LLM repair is new. APIShield's proposed distinction is the evaluated combination of graph context and executable behavioral obligations, with correctness measured by a separate hidden oracle. A future direct comparison must align supported languages, task scope and budgets before attributing differences to these additions. Source: https://arxiv.org/abs/2510.25148v1 .

**Graph-based API misuse repair and migration synthesis.** ASAP-Repair uses API usage graphs and usage templates or change rules [asap2024]. The published 2024 study describes repairing graph representations and discusses further steps toward code repair; this statement concerns that publication, not subsequent implementations. APIShield does not claim novelty in API usage graphs, graph matching, or structural extraction. APIfix learns library adaptations through output-oriented synthesis [apifix2021], while APIDiff detects changes in Java API elements [apidiff2018]. These works establish prior approaches to migration and change detection. APIShield instead targets the joint assessment of contract changes, repository context and inferred behavior in client repairs. Sources: https://doi.org/10.1145/3643788.3648011 , https://doi.org/10.1145/3485538 , https://doi.org/10.1109/SANER.2018.8330249 .

**LLM-based maintenance and repair.** ChatRepair uses conversational repair feedback [chatrepair2024], RepairAgent interleaves repair-related tools through an LLM agent [repairagent2024], and Fruntke and Krinke study LLM-assisted dependency breaking-change repair [dependency2025]. These studies preclude broad novelty claims about feedback-driven patch generation, agentic repair, or dependency migration with LLMs. APIShield's B2 treatment operationalizes ordinary test feedback, while B3-B6 isolate additional graph and behavior-check inputs. SWE-bench supplies an established repository-level evaluation setting [swebench2024], but its issue-resolution tasks do not replace a migration-specific benchmark with explicit behavioral invariants. Sources: https://doi.org/10.1145/3650212.3680323 , https://arxiv.org/abs/2403.17134v2 , https://doi.org/10.1145/3729366 , https://arxiv.org/abs/2310.06770 .

**Invariant inference and independent correctness.** Daikon infers likely invariants from executions [daikon2007], and ClassInvGen co-generates executable class invariants and inputs using LLMs [classinvgen2025]. Therefore, neither dynamic invariant inference nor LLM-generated executable assertions is claimed as a new concept. APIShield proposes to connect inferred obligations to API migration contexts and evaluate their incremental contribution while withholding independent hidden assertions from generation. The distinction between test-suite plausibility and correctness also predates LLM repair: Qi et al. analyze this issue for generate-and-validate systems [plausibility2015]. APIShield adopts this distinction as an evaluation requirement. Sources: https://homes.cs.washington.edu/~mernst/pubs/daikon-tool-scp2007-abstract.html , https://theory.stanford.edu/~barrett/pubs/SAC%2B25-abstract.html , https://doi.org/10.1145/2771783.2771791 .

**REST documentation and testing.** RESTSpecIT infers REST documentation and performs black-box testing through LLM-assisted request mutations [restspecit2025]. It is relevant to obtaining and testing API specifications, whereas the proposed APIShield evaluation concerns preserving client behavior after a contract change. It should not be treated as an interchangeable migration-repair baseline without a justified task adaptation. Source: https://arxiv.org/abs/2402.05102v2 .

## Narrowed novelty statement

The proposed contribution is an empirically testable integration of API-change analysis, structural and inferred semantic repository context, and LLM-inferred executable behavioral assertions for client migration repair, evaluated through matched ablations and an independent behavioral oracle. No claim is made that LLM patching, static graphs, semantic grouping, invariant inference or test feedback is individually new. Superiority over prior systems, causal contribution of each component, and generalization across repositories remain contingent on actual controlled executions. The synthetic tables specify the intended analysis and reporting structure; they substantiate none of these effectiveness claims.

This positioning is scoped to the representative works reviewed here. It is not a systematic-review conclusion establishing priority over all existing literature.


# BibTeX bibliography

```bibtex
@inproceedings{asap2024,
  author = {Sebastian Nielebock and Paul Blockhaus and Jacob Kr{\"u}ger and Frank Ortmeier},
  title = {{ASAP-Repair: API-Specific Automated Program Repair Based on API Usage Graphs}},
  year = {2024},
  doi = {10.1145/3643788.3648011},
  booktitle = {Proceedings of the 5th ACM/IEEE International Workshop on Automated Program Repair},
  pages = {1--4},
  publisher = {ACM}
}

@article{apifix2021,
  author = {Xiang Gao and Arjun Radhakrishna and Gustavo Soares and Ridwan Shariffdeen and Sumit Gulwani and Abhik Roychoudhury},
  title = {{APIfix: output-oriented program synthesis for combating breaking changes in libraries}},
  year = {2021},
  doi = {10.1145/3485538},
  journal = {Proceedings of the ACM on Programming Languages},
  volume = {5},
  number = {OOPSLA},
  pages = {1--27},
  publisher = {Association for Computing Machinery (ACM)}
}

@inproceedings{classinvgen2025,
  author = {Chuyue Sun and Viraj Agashe and Saikat Chakraborty and Jubi Taneja and Clark Barrett and David Dill and Xiaokang Qiu and Shuvendu K. Lahiri},
  title = {{ClassInvGen: Class Invariant Synthesis Using Large Language Models}},
  year = {2025},
  doi = {10.1007/978-3-031-99991-8_4},
  booktitle = {Proceedings of the Second International Symposium on AI Verification (SAIV 2025)},
  pages = {64--96},
  publisher = {Springer Nature Switzerland}
}

@article{daikon2007,
  author = {Michael D. Ernst and Jeff H. Perkins and Philip J. Guo and Stephen McCamant and Carlos Pacheco and Matthew S. Tschantz and Chen Xiao},
  title = {{The Daikon system for dynamic detection of likely invariants}},
  year = {2007},
  doi = {10.1016/j.scico.2007.01.015},
  journal = {Science of Computer Programming},
  volume = {69},
  number = {1-3},
  pages = {35--45},
  publisher = {Elsevier BV}
}

@inproceedings{plausibility2015,
  author = {Zichao Qi and Fan Long and Sara Achour and Martin Rinard},
  title = {{An analysis of patch plausibility and correctness for generate-and-validate patch generation systems}},
  year = {2015},
  doi = {10.1145/2771783.2771791},
  booktitle = {Proceedings of the 2015 International Symposium on Software Testing and Analysis},
  pages = {24--36},
  publisher = {ACM}
}

@inproceedings{chatrepair2024,
  author = {Chunqiu Steven Xia and Lingming Zhang},
  title = {{Automated Program Repair via Conversation: Fixing 162 out of 337 Bugs for \$0.42 Each using ChatGPT}},
  booktitle = {Proceedings of the 33rd ACM SIGSOFT International Symposium on Software Testing and Analysis},
  year = {2024}, publisher = {ACM}, doi = {10.1145/3650212.3680323}
}
@article{dependency2025,
  author = {Lukas Fruntke and Jens Krinke},
  title = {{Automatically Fixing Dependency Breaking Changes}},
  journal = {Proceedings of the ACM on Software Engineering},
  year = {2025}, publisher = {ACM}, doi = {10.1145/3729366}
}
@inproceedings{apidiff2018,
  author = {Aline Brito and Laerte Xavier and Andre Hora and Marco Tulio Valente},
  title = {{APIDiff: Detecting API Breaking Changes}},
  booktitle = {2018 IEEE 25th International Conference on Software Analysis, Evolution and Reengineering (SANER)},
  year = {2018}, publisher = {IEEE}, doi = {10.1109/SANER.2018.8330249}
}
@misc{dcfix2025,
  author = {Katsuki Yamagishi and Norihiro Yoshida and Erina Makihara and Katsuro Inoue},
  title = {{Automated Program Repair Based on REST API Specifications Using Large Language Models}},
  year = {2025}, eprint = {2510.25148}, archivePrefix = {arXiv}, primaryClass = {cs.SE},
  doi = {10.48550/arXiv.2510.25148}, url = {https://arxiv.org/abs/2510.25148v1},
  note = {Preprint, version 1}
}
@misc{repairagent2024,
  author = {Islem Bouzenia and Premkumar Devanbu and Michael Pradel},
  title = {{RepairAgent: An Autonomous, LLM-Based Agent for Program Repair}},
  year = {2024}, eprint = {2403.17134}, archivePrefix = {arXiv}, primaryClass = {cs.SE},
  doi = {10.48550/arXiv.2403.17134}, url = {https://arxiv.org/abs/2403.17134v2},
  note = {Preprint, version 2}
}
@misc{restspecit2025,
  author = {Alix Decrop and Xavier Devroey and Mike Papadakis and Pierre-Yves Schobbens and Gilles Perrouin},
  title = {{You Can REST Now: Automated REST API Documentation and Testing via LLM-Assisted Request Mutations}},
  year = {2025}, eprint = {2402.05102}, archivePrefix = {arXiv}, primaryClass = {cs.SE},
  doi = {10.48550/arXiv.2402.05102}, url = {https://arxiv.org/abs/2402.05102v2},
  note = {Preprint, version 2, revised July 2025}
}
@inproceedings{swebench2024,
  author = {Carlos E. Jimenez and John Yang and Alexander Wettig and Shunyu Yao and Kexin Pei and Ofir Press and Karthik Narasimhan},
  title = {{SWE-bench: Can Language Models Resolve Real-World GitHub Issues?}},
  booktitle = {The Twelfth International Conference on Learning Representations},
  year = {2024}, url = {https://arxiv.org/abs/2310.06770}
}

```


# Complete artifact source: schemas/experiment-record.schema.json

```json
{
  "$schema":"https://json-schema.org/draft/2020-12/schema",
  "$id":"urn:apishield:experiment-record:1.0",
  "title":"APIShield typed experiment record 1.0",
  "type":"object",
  "additionalProperties":false,
  "required":["schema_version","evidence_kind","task_id","config_id","model_requested","model_resolved_snapshot","git_commit_sha","git_commit_identifies_run","runtime_s","prompt_tokens","completion_tokens","token_accounting","repair_attempts","hidden_invariants_status","oracle_verdict","original_record_path"],
  "properties":{
    "schema_version":{"const":"1.0"},
    "evidence_kind":{"enum":["synthetic_projection","live_inference","fixture_replay"]},
    "task_id":{"type":"string","minLength":1},
    "config_id":{"enum":["B1","B2","B3","B4","B5","B6"]},
    "model_requested":{"type":["string","null"]},
    "model_resolved_snapshot":{"oneOf":[{"type":"null"},{"type":"object","additionalProperties":false,"required":["provider_returned_id","immutable_verified","identity_kind"],"properties":{"provider_returned_id":{"type":"string","minLength":1},"immutable_verified":{"type":"boolean"},"identity_kind":{"enum":["provider_returned_version","verified_immutable_snapshot"]}}}]},
    "git_commit_sha":{"type":["string","null"],"pattern":"^[0-9a-f]{40}$"},
    "git_commit_identifies_run":{"type":"boolean"},
    "runtime_s":{"type":"number","minimum":0},
    "prompt_tokens":{"type":["integer","null"],"minimum":0},
    "completion_tokens":{"type":["integer","null"],"minimum":0},
    "token_accounting":{"enum":["measured_aggregate_all_model_calls","synthetic_aggregate_including_retry_allowance","no_model_invoked","unknown_transport_usage"]},
    "repair_attempts":{"type":["integer","null"],"minimum":1},
    "hidden_invariants_status":{"type":"object","additionalProperties":false,"required":["evaluated","checks"],"properties":{"evaluated":{"type":"boolean"},"checks":{"type":"object","additionalProperties":{"type":"boolean"}}},"allOf":[{"if":{"properties":{"evaluated":{"const":false}}},"then":{"properties":{"checks":{"maxProperties":0}}}}]},
    "oracle_verdict":{"enum":["PASS","FAIL","NOT_EVALUATED","EXECUTION_ERROR"]},
    "original_record_path":{"type":"string","minLength":1}
  },
  "allOf":[
    {"if":{"properties":{"evidence_kind":{"const":"synthetic_projection"}}},"then":{"properties":{"model_requested":{"type":"null"},"model_resolved_snapshot":{"type":"null"},"git_commit_identifies_run":{"const":false}}}},
    {"if":{"properties":{"oracle_verdict":{"enum":["PASS","FAIL"]}}},"then":{"properties":{"hidden_invariants_status":{"properties":{"evaluated":{"const":true},"checks":{"minProperties":1}}}}}}
  ]
}

```


# Complete artifact source: scripts/analyze.py

```python
"""Recompute labelled synthetic tables; never pool them with observed execution logs."""
import argparse
import json
from pathlib import Path

import numpy as np
import pandas as pd
from scipy.stats import norm

ROOT=Path(__file__).resolve().parents[1]

def wilson(successes,total):
    if total<=0:return None,None
    z=norm.ppf(.975);p=successes/total;den=1+z*z/total
    mid=(p+z*z/(2*total))/den
    half=z*np.sqrt(p*(1-p)/total+z*z/(4*total*total))/den
    return float(mid-half),float(mid+half)

def cliffs_delta(x,y):
    difference=np.asarray(x)[:,None]-np.asarray(y)[None,:]
    return float(((difference>0).sum()-(difference<0).sum())/difference.size)

def paired_bootstrap(left,right,families,draws=20000):
    rng=np.random.default_rng(42)
    groups=[np.flatnonzero(families==family) for family in sorted(set(families))]
    deltas=[];ratios=[]
    for _ in range(draws):
        index=np.concatenate([rng.choice(group,len(group),replace=True) for group in groups])
        # For binary outcomes, marginal Cliff's delta equals the difference in means.
        deltas.append(float((left[index]-right[index]).mean()))
        ratios.append(float(left[index].mean()-right[index].mean()))
    return np.quantile(deltas,[.025,.975]).tolist(),np.quantile(ratios,[.025,.975]).tolist()

def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--data',type=Path,default=ROOT/'data/synthetic/synthetic_outcomes.csv')
    p.add_argument('--output',type=Path,default=ROOT/'analysis')
    args=p.parse_args()
    frame=pd.read_csv(args.data)
    if set(frame.record_kind)!={'SYNTHETIC_PROJECTION'}:
        raise ValueError('This analysis accepts only explicitly synthetic records')
    if frame.duplicated(['task_id','configuration']).any():raise ValueError('Duplicate task/configuration')
    if set(frame.configuration)!={f'B{i}' for i in range(1,7)}:raise ValueError('Expected B1-B6')
    frame['domain']=frame.task_id.str.split('-').str[1]
    for column in ['hidden_pass','visible_pass']:
        if not pd.api.types.is_bool_dtype(frame[column]):raise ValueError('Expected boolean outcomes')
    if (frame.hidden_pass & ~frame.visible_pass).any():raise ValueError('Hidden correctness requires visible success')
    # Retry allocations are explicit synthetic budgeting assumptions, not recovered measurements.
    extras={'B1':0,'B2':72,'B3':60,'B4':54,'B5':42,'B6':30}
    enriched=[];summaries=[]
    for config,original in frame.groupby('configuration',sort=True):
        group=original.sort_values('task_id').copy()
        if len(group)!=120:raise ValueError('Expected 120 tasks per configuration')
        attempts=np.ones(120,dtype=int)
        ranking=np.argsort(-group.wall_seconds.to_numpy())
        for index in range(extras[config]):attempts[ranking[index%120]]+=1
        group['synthetic_repair_attempts']=attempts
        group['token_accounting']='aggregate_including_all_attempts_and_model_stages'
        api=(.75*group.prompt_tokens+3.75*group.completion_including_reasoning_tokens)/1e6
        cost=api+group.wall_seconds*(.08+.065*.20)/3600
        if not np.allclose(api,group.estimated_api_usd):raise ValueError('API cost identity failed')
        if not np.allclose(cost,group.modeled_total_usd):raise ValueError('Total cost identity failed')
        v=int(group.visible_pass.sum());h=int(group.hidden_pass.sum());n=len(group)
        vlo,vhi=wilson(v,n);hlo,hhi=wilson(h,n)
        summaries.append(dict(config_id=config,tasks=n,visible_successes=v,visible_rate=v/n,
            visible_ci_low=vlo,visible_ci_high=vhi,hidden_successes=h,hidden_rate=h/n,
            hidden_ci_low=hlo,hidden_ci_high=hhi,
            detection_precision=float(group.true_affected_localized.sum()/(group.true_affected_localized.sum()+group.unaffected_false_alarm.sum())),
            detection_recall=float(group.true_affected_localized.mean()),
            prompt_tokens_total=int(group.prompt_tokens.sum()),completion_tokens_total=int(group.completion_including_reasoning_tokens.sum()),
            mean_repair_attempts=float(attempts.mean()),runtime_mean=float(group.wall_seconds.mean()),
            runtime_sd=float(group.wall_seconds.std(ddof=1)),api_cost_total=float(api.sum()),
            host_cost_total=float((cost-api).sum()),failure_inclusive_cost_total=float(cost.sum()),
            failure_inclusive_cost_per_hidden_correct=float(cost.sum()/h)))
        enriched.append(group)
    frame=pd.concat(enriched,ignore_index=True)
    effects=[]
    for baseline in ['B2','B3']:
        paired=frame[frame.configuration.isin(['B6',baseline])].pivot(index='task_id',columns='configuration',values='hidden_pass').sort_index()
        left=paired['B6'].astype(int).to_numpy();right=paired[baseline].astype(int).to_numpy()
        families=paired.index.to_series().str.split('-').str[1].to_numpy()
        rd_ci,delta_ci=paired_bootstrap(left,right,families)
        effects.append(dict(contrast='B6-'+baseline,paired_tasks=len(paired),risk_difference=float((left-right).mean()),
            paired_stratified_bootstrap_95=rd_ci,cliffs_delta=cliffs_delta(left,right),
            cliffs_delta_paired_stratified_bootstrap_95=delta_ci,
            baseline_only=int(((left==0)&(right==1)).sum()),full_only=int(((left==1)&(right==0)).sum()),
            both_correct=int(((left==1)&(right==1)).sum()),neither_correct=int(((left==0)&(right==0)).sum())))
    args.output.mkdir(parents=True,exist_ok=True)
    pd.DataFrame(summaries).to_csv(args.output/'comparison.csv',index=False)
    frame.to_csv(args.output/'synthetic_accounting.csv',index=False)
    report={'evidence_kind':'synthetic_projection','empirical_claims_supported':False,'schema_version':'1.0',
        'bootstrap_seed':42,'bootstrap_draws':20000,'bootstrap_unit':'paired task, stratified by four domains',
        'ci_scope':'Conditional on stipulated scenario; excludes uncertainty about true effectiveness',
        'family_limitation':'Domains are strata, not independent repository families; future related tasks require family-cluster resampling',
        'retry_accounting':'Synthetic attempts; total tokens already include retry allowances; never multiply aggregate tokens by attempts again',
        'summaries':summaries,'effects':effects}
    (args.output/'metrics.json').write_text(json.dumps(report,indent=2,allow_nan=False)+'\n')
    lines=['# Synthetic projection: computed comparison tables\n',
        '**Table 1: Synthetic Benchmark Projection & Ablation Model (N=120).**\n',
        '| Config | Visible successes; % [95% Wilson CI] | Hidden successes; % [95% Wilson CI] | Mean attempts | Runtime s, mean ± SD | API USD | Host USD | Total USD | USD/hidden-correct |',
        '|---|---|---|---:|---:|---:|---:|---:|---:|']
    for r in summaries:
        lines.append(f"| {r['config_id']} | {r['visible_successes']}/120; {100*r['visible_rate']:.1f} [{100*r['visible_ci_low']:.1f}, {100*r['visible_ci_high']:.1f}] | {r['hidden_successes']}/120; {100*r['hidden_rate']:.1f} [{100*r['hidden_ci_low']:.1f}, {100*r['hidden_ci_high']:.1f}] | {r['mean_repair_attempts']:.2f} | {r['runtime_mean']:.1f} ± {r['runtime_sd']:.1f} | {r['api_cost_total']:.4f} | {r['host_cost_total']:.4f} | {r['failure_inclusive_cost_total']:.4f} | {r['failure_inclusive_cost_per_hidden_correct']:.5f} |")
    lines += ['\n**Table 2: Synthetic Benchmark Projection & Ablation Model (N=120). Primary paired contrasts.**\n',
        '| Contrast | Hidden difference, pp [bootstrap 95% CI] | Cliff delta [bootstrap 95% CI] | B6-only / baseline-only / both / neither |',
        '|---|---|---|---|']
    for e in effects:
        lo,hi=e['paired_stratified_bootstrap_95'];dl,dh=e['cliffs_delta_paired_stratified_bootstrap_95']
        lines.append(f"| {e['contrast']} | {100*e['risk_difference']:.1f} [{100*lo:.1f}, {100*hi:.1f}] | {e['cliffs_delta']:.3f} [{dl:.3f}, {dh:.3f}] | {e['full_only']} / {e['baseline_only']} / {e['both_correct']} / {e['neither_correct']} |")
    (args.output/'tables.md').write_text('\n'.join(lines)+'\n',encoding='utf-8')
    print(json.dumps({'synthetic_records':len(frame),'output':str(args.output),'effects':effects},indent=2))

if __name__=='__main__':main()

```


# Complete artifact source: scripts/headless.py

```python
"""Portable single-case qualification; generated candidates require Docker."""
import argparse
import json
import subprocess
import sys
from pathlib import Path
from types import SimpleNamespace

ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT))

def main():
    from benchmarks.harness.run_ablation import run_one,valid_image
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--task',default='TASK-BANK-014')
    p.add_argument('--config',choices=[f'B{i}' for i in range(1,7)],default='B6')
    p.add_argument('--mode',choices=['fixture','live'],default='fixture')
    p.add_argument('--image')
    p.add_argument('--execute-live',action='store_true')
    p.add_argument('--allow-unpinned-provider',action='store_true')
    p.add_argument('--output',type=Path,required=True)
    args=p.parse_args()
    if args.mode=='live':
        if not args.execute_live or not valid_image(args.image):p.error('Live mode requires explicit execution and a resolved Docker image digest')
        if not args.allow_unpinned_provider:p.error('Current provider is not verified immutable; diagnostic live mode requires explicit override')
        subprocess.run(['docker','info'],capture_output=True,check=True,timeout=15)
        subprocess.run(['docker','image','inspect',args.image],capture_output=True,check=True,timeout=15)
    tasks=json.loads((ROOT/'benchmarks/tasks_manifest.json').read_text())['tasks']
    task=next((t for t in tasks if t['task_id']==args.task),None)
    if task is None:p.error('Only the four retained executable qualification tasks are available')
    for key,value in task.items():
        if isinstance(value,str) and value.startswith('C:/Users/surji/ProjectSeven/'):
            task[key]=str(ROOT/value.removeprefix('C:/Users/surji/ProjectSeven/'))
    flags=json.loads((ROOT/'benchmarks/configurations.json').read_text())[args.config]
    args.output=args.output.resolve();args.output.mkdir(parents=True,exist_ok=False)
    runtime=SimpleNamespace(repetition=1,mode=args.mode,provider='google-cloud',
        boundary='docker' if args.mode=='live' else 'trusted-fixtures',image=args.image,generation_only=False)
    trace=run_one(task,args.config,flags,runtime,args.output)
    print(json.dumps({'run_id':trace['run_id'],'evidence_kind':trace['record_kind'],
        'classification':trace['classification'],'independent_correct':trace['record']['independent_correct']},indent=2))
    if trace['classification']=='INFRASTRUCTURE_ERROR':raise SystemExit(1)

if __name__=='__main__':main()

```


# Complete artifact source: scripts/package.py

```python
"""Build a content-verified local review artifact, with explicit evidence categories."""
import argparse
import gzip
import hashlib
import json
import re
import subprocess
import tarfile
from pathlib import Path

ROOT=Path(__file__).resolve().parents[1]
EXCLUDE={'.venv','venv','__pycache__','.pytest_cache','.git','models','analysis-reproduced'}

def digest(raw):
    return {'sha256':hashlib.sha256(raw).hexdigest(),'md5':hashlib.md5(raw,usedforsecurity=False).hexdigest(),'bytes':len(raw)}

def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--output',type=Path,required=True)
    args=p.parse_args();args.output=args.output.resolve()
    if args.output.exists():raise ValueError('Choose a new archive filename to preserve retained evidence')
    if args.output.is_relative_to(ROOT):raise ValueError('Archive must be written outside its own payload')
    status={'package_version':'1.0','package_kind':'synthetic_layout_and_actual_inference_diagnostics',
        'empirical_120_task_evaluation_complete':False,'synthetic_outcome_rows':720,'executable_qualification_tasks':4,
        'original_diagnostic_task_traces':18,'normalized_completed_inference_records':6,'fixture_qualification_traces':24,
        'model_requested':'gemini-3.8-flash','immutable_model_snapshot_verified':False,
        'source_git_head':'80e7bbe0c01b58fa6615098c1bc56c6534a830eb','source_head_identifies_artifact':False,
        'public_archive_deposited':False,'doi_status':'not_assigned','artifact_badge_status':'not_awarded',
        'author_status':'anonymous_structural_review','license_status':'owner_confirmation_required_before_public_distribution',
        'schema_versions':{'normalized_experiment_record':'1.0','raw_run_columns':56,'qualification_task_manifest':1},
        'container_evaluation_observed':False,'local_open_weight_inference_observed':False}
    (ROOT/'ARCHIVE_STATUS.json').write_text(json.dumps(status,indent=2)+'\n')
    files=[]
    for path in ROOT.rglob('*'):
        rel=path.relative_to(ROOT)
        if any(part in EXCLUDE for part in rel.parts):continue
        if path.is_symlink():raise ValueError('Unexpected symlink: '+str(rel))
        if not path.is_file() or path.name in {'MANIFEST.json','DIRECTORY_MANIFEST.txt'}:continue
        if path.name=='.env' or path.name.startswith('.env.') or path.name=='service-account.json':
            raise ValueError('Credential-bearing filename disallowed')
        raw=path.read_bytes()
        if re.search(rb'-----BEGIN (?:RSA )?PRIVATE KEY-----\s+[A-Za-z0-9+/=\r\n]{80,}-----END (?:RSA )?PRIVATE KEY-----',raw):
            raise ValueError('Private key material disallowed')
        files.append(path)
    listing=sorted([p.relative_to(ROOT).as_posix() for p in files]+['MANIFEST.json','DIRECTORY_MANIFEST.txt'])
    directory=ROOT/'DIRECTORY_MANIFEST.txt'
    directory.write_text('APIShield-evaluation-v1.0/\n'+'\n'.join('  '+name for name in listing)+'\n')
    files.append(directory)
    records={p.relative_to(ROOT).as_posix():digest(p.read_bytes()) for p in sorted(files)}
    manifest=ROOT/'MANIFEST.json'
    manifest.write_text(json.dumps({'schema_version':'1.0','evidence_status':status['package_kind'],
        'excludes_self':True,'files':records},indent=2)+'\n')
    files.append(manifest)
    args.output.parent.mkdir(parents=True,exist_ok=True)
    with args.output.open('wb') as raw:
        with gzip.GzipFile(filename='',mode='wb',fileobj=raw,mtime=0) as compressed:
            with tarfile.open(fileobj=compressed,mode='w') as archive:
                for path in sorted(files):
                    name='APIShield-evaluation-v1.0/'+path.relative_to(ROOT).as_posix()
                    info=archive.gettarinfo(str(path),arcname=name)
                    info.uid=info.gid=0;info.uname=info.gname='';info.mtime=0;info.mode=0o644
                    with path.open('rb') as source:archive.addfile(info,source)
    with tarfile.open(args.output,'r:gz') as archive:
        for name,expected in records.items():
            assert digest(archive.extractfile('APIShield-evaluation-v1.0/'+name).read())==expected,name
    observed=digest(args.output.read_bytes())
    for algorithm in ['sha256','md5']:
        args.output.with_name(args.output.name+'.'+algorithm).write_text(observed[algorithm]+'  '+args.output.name+'\n')
    args.output.with_name(args.output.name+'.manifest.json').write_text(json.dumps({'archive':args.output.name,
        **observed,'payload_files':len(files),'internal_manifest':digest(manifest.read_bytes()),
        'status':status},indent=2)+'\n')
    print(json.dumps({'archive':str(args.output),'files':len(files),**observed},indent=2))

if __name__=='__main__':main()

```


# Complete artifact source: scripts/verify_environment.py

```python
"""Verify archive bytes and report local capabilities without requiring a GPU."""
import argparse
import hashlib
import importlib.metadata
import json
import platform
import shutil
import subprocess
import sys
from pathlib import Path

ROOT=Path(__file__).resolve().parents[1]

def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--require-docker',action='store_true')
    args=p.parse_args()
    manifest=json.loads((ROOT/'MANIFEST.json').read_text())
    for rel,expected in manifest['files'].items():
        path=ROOT/rel
        if hashlib.sha256(path.read_bytes()).hexdigest()!=expected['sha256']:raise ValueError('Payload mismatch: '+rel)
    deps={name:importlib.metadata.version(name) for name in ['numpy','pandas','scipy']}
    docker=False
    if shutil.which('docker'):
        try:docker=subprocess.run(['docker','info'],capture_output=True,timeout=15).returncode==0
        except (OSError,subprocess.TimeoutExpired):pass
    report={'python':sys.version,'platform':platform.platform(),'dependencies':deps,
        'payload_files_verified':len(manifest['files']),'docker_engine_available':docker,
        'llama_server_available':bool(shutil.which('llama-server')),'nvidia_smi_available':bool(shutil.which('nvidia-smi')),
        'empirical_120_task_evaluation_present':False,'evidence_status':'synthetic manuscript layout plus observed diagnostics and authored fixtures'}
    print(json.dumps(report,indent=2))
    if args.require_docker and not docker:raise SystemExit(2)

if __name__=='__main__':main()

```
