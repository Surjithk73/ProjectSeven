"""Explicit research backend. Fixture mode never calls this adapter."""
import hashlib
import json
import time
from pathlib import Path

class Backend:
    def __init__(self, provider, profile, output):
        self.provider,self.profile,self.output=provider,profile,output
        self.calls=[]
        if provider=='llama-cpp':
            path=Path(profile['local_weight_path'])
            if not path.is_file():raise ValueError('Configured GGUF file is absent; no local provenance can be asserted')
            digest=hashlib.file_digest(path.open('rb'),'sha256').hexdigest()
            if digest != profile['published_weight_sha256']:raise ValueError('Local GGUF hash does not match pinned published fingerprint')
            if not profile['inference_engine_version']:raise ValueError('Record the actual llama-server build version before live research')

    def generate(self, prompt, stage):
        import httpx
        last=None
        for retry in range(4):
            start=time.perf_counter()
            call={'stage':stage,'retry_index':retry,'prompt_sha256':hashlib.sha256(prompt.encode()).hexdigest(),'raw_prompt':prompt,
                  'generation_parameters':{'temperature':.1,'top_p':.95,'seed':42,'max_output_tokens':4096}}
            try:
                if self.provider=='google-cloud':
                    from apishield.model_access import environment_connection,model_client
                    from google.genai import types
                    with model_client(environment_connection(),time.monotonic()+120) as client:
                        result=client.models.generate_content(model=self.profile['requested_model'],contents=prompt,
                            config=types.GenerateContentConfig(temperature=.1,top_p=.95,seed=42,max_output_tokens=4096,
                                response_mime_type='application/json',thinking_config=types.ThinkingConfig(thinking_level='LOW'),
                                automatic_function_calling=types.AutomaticFunctionCallingConfig(disable=True)))
                    usage=result.usage_metadata
                    call.update(resolved_model_version=getattr(result,'model_version',None),
                                prompt_tokens=getattr(usage,'prompt_token_count',0) or 0,cached_tokens=getattr(usage,'cached_content_token_count',0) or 0,
                                output_tokens=getattr(usage,'candidates_token_count',0) or 0,reasoning_tokens=getattr(usage,'thoughts_token_count',0) or 0,
                                response=result.model_dump(mode='json'),response_text=result.text,http_status=200)
                else:
                    body={'model':self.profile['repository'],'messages':[{'role':'user','content':prompt}],
                          'temperature':.1,'top_p':.95,'seed':42,'max_tokens':4096,'stream':False}
                    response=httpx.post(self.profile['endpoint'],json=body,timeout=120);response.raise_for_status()
                    result=response.json();usage=result.get('usage',{})
                    call.update(resolved_model_version=result.get('model'),prompt_tokens=usage.get('prompt_tokens',0),cached_tokens=0,
                                output_tokens=usage.get('completion_tokens',0),reasoning_tokens=0,response=result,
                                response_text=result['choices'][0]['message']['content'],http_status=200)
                parsed=json.loads(call['response_text'])
                call['elapsed_seconds']=time.perf_counter()-start
                self.calls.append(call);self._save()
                return parsed
            except Exception as error:
                status=getattr(error,'code',None) or getattr(getattr(error,'response',None),'status_code',None)
                call.update(elapsed_seconds=time.perf_counter()-start,http_status=call.get('http_status',status),error_category=type(error).__name__)
                self.calls.append(call);self._save();last=error
                if status not in [429,500,502,503,504] or retry==3:break
                time.sleep([1,2,4][retry])
        raise RuntimeError(f'Model request failed; category={type(last).__name__}; no provider fallback') from None

    def _save(self):
        self.output.write_text(json.dumps(self.calls,indent=2),encoding='utf-8')
