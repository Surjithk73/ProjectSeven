"""Controller-side test execution; oracle source never enters candidate mounts."""
import importlib.util
import json
import re
import subprocess
import sys
from pathlib import Path

WORKER=Path(__file__).with_name('candidate_worker.py')

def execute(workspace, inputs, boundary, image=None):
    if boundary == 'docker':
        if not image or not re.fullmatch(r'[^\s]+@sha256:[0-9a-f]{64}',image):
            raise ValueError('Docker execution requires an actually resolved image@sha256 digest')
        cmd=['docker','run','--rm','--network','none','--read-only','--cap-drop','ALL',
             '--security-opt','no-new-privileges','--pids-limit','64','--memory','512m','--cpus','1',
             '--tmpfs','/tmp:rw,noexec,nosuid,size=64m','--user','65534:65534',
             '--mount',f'type=bind,source={workspace.resolve()},target=/work,readonly',
             '--mount',f'type=bind,source={WORKER.resolve()},target=/runner.py,readonly',
             '--workdir','/work','-i',image,'python','-B','/runner.py']
    elif boundary == 'trusted-fixtures':
        cmd=[sys.executable,'-I','-B',str(WORKER)]
    else:raise ValueError('Unknown execution boundary')
    result=subprocess.run(cmd,input=json.dumps(inputs),text=True,capture_output=True,cwd=workspace,timeout=30,
                          env={'SYSTEMROOT':__import__('os').environ.get('SYSTEMROOT','C:/Windows'), 'PYTHONIOENCODING':'utf-8'})
    value=None
    if result.returncode==0:
        try:value=json.loads(result.stdout)
        except ValueError:pass
    return result,value

def judge(suite, inputs, outputs):
    spec=importlib.util.spec_from_file_location('qualification_oracle',suite)
    module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module)
    try:
        checks=module.evaluate(inputs,outputs)
        if not isinstance(checks,dict) or not checks or any(type(v) is not bool for v in checks.values()):
            raise ValueError('Oracle must return nonempty named boolean assertions')
        return checks
    except (KeyError,TypeError,IndexError):return {'oracle_contract':False}
