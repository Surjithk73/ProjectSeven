APIShield LaTeX source package

Upload this ZIP as a new Overleaf project. Select tosem-review.tex for ACM TOSEM,
or tse-review.tex for IEEE TSE, as the main document. Compile with pdfLaTeX and
BibTeX (Overleaf normally handles the required repeat passes), then Download PDF.

The five source files are unchanged copies from paper_submission_bundle.
Both templates need sections.tex, author-metadata.tex and references.bib.
This ZIP is source only; no PDF compilation or rendered-layout validation was
possible in this session. See the separate manuscript review before submission.
